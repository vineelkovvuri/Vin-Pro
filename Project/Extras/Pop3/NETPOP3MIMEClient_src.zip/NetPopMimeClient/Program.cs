using System;
using System.Collections.Generic;
using System.Text;

using Net.Mail;
using Net.Mime;

namespace NetPopMimeClient
{
    internal class Program
    {
        private const string PopServer = "pop.gmail.com";
        private const int PopPort = 995;
        private const string User = "";
        private const string Pass = "";

        private static void Main(string[] args)
        {
            using (Pop3Client client = new Pop3Client(PopServer, PopPort, true, User, Pass))
            {
                client.Trace += new Action<string>(Console.WriteLine);
                //connects to Pop3 Server, Executes POP3 USER and PASS
                client.Authenticate();
                //
                client.Stat();
                foreach (Pop3ListItem item in client.List())
                {
                    MailMessageEx message = client.RetrMailMessageEx(item);
                    Console.WriteLine("Children.Count: {0}", message.Children.Count);
                    Console.WriteLine("message-id: {0}", message.MessageId);
                    Console.WriteLine("subject: {0}", message.Subject);
                    Console.WriteLine("Attachments.Count: {0}", message.Attachments.Count);
                    client.Dele(item);
                }
                client.Noop();
                client.Rset();
                client.Quit();
            }

            Console.ReadLine();
        }
    }
}
