using System;
using System.IO;
using System.Collections;
using System.Windows.Forms;
using System.Threading;
namespace TurboFindFiles
{
	/// <summary>
	/// This will do the actual searching for the file(s)
	/// </summary>
	/// 
	public class Searcher
	{
		public Searcher()
		{
			// 
			// TODO: Add constructor logic here
			//
		}
		// Event handling routine
		public class FileParseEventArgs : EventArgs
		{
			public FileParseEventArgs(string strOutMsg)
			{
				this.strMsg = strOutMsg;
			}
			public readonly string strMsg;
		}
		public class FileMatchEventArgs : EventArgs
		{
			public FileMatchEventArgs(CFileNode Outnode)
			{
				this.node = Outnode;
			}
			public readonly CFileNode node;
		}
		public delegate void ParsingFileEventHandler(object ob, FileParseEventArgs args);
		public delegate void LocatedFileEventHandler(object ob, FileMatchEventArgs args);
		public delegate void CompletedEventHandler(object ob);
		public event ParsingFileEventHandler ParseFileMsg;
		public event LocatedFileEventHandler LocatedFileMsg;
		public event CompletedEventHandler CompletedMsg;
		protected virtual void OnComplete()
		{
			if(CompletedMsg != null)
			{
				CompletedMsg(this);
			}
		}
		protected virtual void OnParsingFileMsg(FileParseEventArgs arg)
		{
			if(ParseFileMsg != null)
			{
				ParseFileMsg(this, arg);
			}
		}
		protected virtual void OnLocatedFileMsg(FileMatchEventArgs arg)
		{
			if(LocatedFileMsg != null)
			{
				LocatedFileMsg(this, arg);
			}
		}
			//
		public CFileNode[] FileCollection; 
		private bool FileHasText(string strFullFilePath, string strContainsText)
		{
			bool bRet = false;
			return bRet;
		}
		private bool FileHasAttributes(FileAttributes attribs)
		{
			bool bret = false;
			return bret;
		}
		private void FindFile(string strSearchPath, string strCriteria, FileAttributes attribs, string strContainsText)
		{
			String[] strFiles;
			String[] strDirectories;
			CFileNode fileNode;
			strDirectories = Directory.GetDirectories(strSearchPath);
			strFiles = Directory.GetFiles(strSearchPath, strCriteria);
			StreamReader stream;
			string strFileContents;
			int nSz = 0;
			bool bNoMatch = false;	
			try
			{
				if(bEndSearch == true)
					return;
				foreach(String strFile in strFiles)
				{
					if(bEndSearch == true)
						return;
					try
					{
						stream = new StreamReader(new FileStream(strFile, FileMode.Open, FileAccess.Read));
						strFileContents = stream.ReadToEnd();
						nSz = strFileContents.Length;
						FileAttributes FileAttribs = File.GetAttributes(strFile);
						if(strContainsText.Length > 0)
						{
							if(strFileContents.IndexOf(strContainsText) == -1)
								bNoMatch = true;
						}
						if(bNoMatch == false)
						{
							if((FileAttribs & attribs) == 0)
								bNoMatch = true;
						}
						if(bNoMatch == false)
						{
							fileNode = new CFileNode(strFile);
							fileNode.Size = nSz;
							//tell the client that I am about to add this file to the list of matching files
							FileMatchEventArgs arg = new FileMatchEventArgs(fileNode);
							OnLocatedFileMsg(arg);
							//
							++nMatchingFiles;
						}
						stream.Close();
					}
					catch
					{
						MessageBox.Show("Unknown Error", "Search(File) Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				foreach(String strDir in strDirectories)
				{
					try
					{
						if(strDir == "." || strDir == ".." || strDir.Length == 0)
							continue;
						if(bEndSearch == true)
							return;
						//tell the client that I am about to parse this directory
						FileParseEventArgs arg = new FileParseEventArgs(strDir);
						OnParsingFileMsg(arg);
						//
						if(strDir.IndexOf("System") != -1)
							nSz = nSz;
						FindFile(strDir, strCriteria, attribs, strContainsText);
					}
					catch
					{
						MessageBox.Show("Unknown Error", "Search(Dir) Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
			}
			catch(IOException e)
			{
				MessageBox.Show(e.Message, "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			catch(ArgumentException e)
			{
				MessageBox.Show(e.Message, "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			catch(NotSupportedException e)
			{
				MessageBox.Show(e.Message, "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			catch
			{
				MessageBox.Show("Unknown Error", "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}
		public void AddFile()
		{

		}
		public uint nMatchingFiles = 0;
		private bool bEndSearch = false;
		private readonly int nMember = 6;
		private Thread worker;
		private ArrayList searchStartPath;
		private string searchCriteria;
		private string containsText;
		private FileAttributes fileAttribs;

		public void ThreadFn()
		{
			int nLocal = nMember;
			try
			{
				foreach(string path in searchStartPath)
				{
					if(Directory.Exists(path))
					{
						FindFile(path, searchCriteria, fileAttribs, containsText);
						OnComplete();
					}
					else
					{
						MessageBox.Show("Invalid Directory", "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
			}
			catch(ArgumentException e)
			{
				MessageBox.Show(e.Message, "Argument Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			catch
			{
				MessageBox.Show("Invalid Directory", "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}


		public void BeginSearch(ArrayList strSearchStartPath, string strCriteria, FileAttributes attribs, string strContainsText, ref ArrayList strFileCollection)
		{
			searchStartPath = strSearchStartPath;
			searchCriteria = strCriteria;
			fileAttribs = attribs;
			containsText = strContainsText;
			bEndSearch = false;
			nMatchingFiles = 0;
			worker = new Thread( new ThreadStart(ThreadFn));
			worker.Start();
		}
		
		public string[] GetLocalDrives()
		{
			return null;
		}

		public void EndSerach()
		{
			bEndSearch = true;
		}
	}
}
