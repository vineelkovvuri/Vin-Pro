using System;
using System.IO;

namespace TurboFindFiles
{
	/// <summary>
	/// This is used to hold the attributes of each file/directory found
	/// </summary>
	public class CFileNode
	{
		public CFileNode()
		{
			// 
			// TODO: Add constructor logic here
			//
		}
		public CFileNode(string strFile)
		{
			m_strFileName = GetPathSection(strFile, 2);
			m_strFolder = GetPathSection(strFile, 1);
			m_Created = File.GetCreationTime(strFile);
			m_LastModified = File.GetLastWriteTime(strFile);
		}
		private String GetPathSection(String strFile, int nPathSection)
		{
			String strPath, strFileName, strReturn = "";
			int nLen = strFile.Length, nCnt = 0;
			for(int n = nLen - 1; n >= 0; --n)
			{
				if(strFile[n] == '\\')
					break;
				++nCnt;
			}
			if(nCnt > 0)
			{
				strFileName = strFile.Substring(nLen - nCnt, nCnt);
				strPath = strFile.Substring(0, (nLen - nCnt) - 1);
				if(nPathSection == 1)
					strReturn = strPath;
				else if(nPathSection == 2)
					strReturn = strFileName;
			}
			return strReturn;
		}
		public bool m_bIsReadOnly
		{
			get
			{
				return true;
			}
			set
			{
			}
		}

		public int m_bIsTemporary
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public int m_bIsDirectory
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public int m_IsSystem
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}
		public int m_bIsArchive
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public int m_bIsCompressed
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public int m_bIsHidden
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		/// <summary>
		/// This will show the full path of the file
		/// </summary>
		public int m_strFilePath
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public long m_lFileSize
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public string strFileName
		{
			get
			{
				return m_strFileName;
			}
			set
			{
				m_strFileName = value;
			}
		}

		public string strFolder
		{
			get
			{
				return m_strFolder;
			}
			set
			{
				m_strFolder = value;
			}
		}

		public long Size
		{
			get
			{
				return m_nSize;
			}
			set
			{
				m_nSize = value;
			}
		}
		private long m_nSize;
		private string m_strFileName;
		private string m_strFolder;
		private DateTime m_Created;
		private DateTime m_LastModified;

		public DateTime DateCreated
		{
			get
			{
				return m_Created;
			}
			set
			{
				m_Created = value;
			}
		}

		public DateTime LastModified
		{
			get
			{
				return m_LastModified;
			}
			set
			{
				m_LastModified = value;
			}
		}
	}
}
