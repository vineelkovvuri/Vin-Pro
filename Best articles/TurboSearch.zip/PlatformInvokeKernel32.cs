using System;
using System.Runtime.InteropServices;

namespace TurboFindFiles
{
	/// <summary>
	/// Accesses the kenel for disk information
	/// </summary>
	public class PlatformInvokeKernel32
	{
		public PlatformInvokeKernel32()
		{
			// 
			// TODO: Add constructor logic here
			//
		}
		[DllImport("kernel32")]
		public static extern int GetDriveType (string lpRootPathName); 

	}
}
