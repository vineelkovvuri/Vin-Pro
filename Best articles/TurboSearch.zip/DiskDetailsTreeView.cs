using System;
using System.Windows.Forms;
using System.Collections;
using System.Drawing;
using System.IO;

namespace TurboFindFiles
{
	/// <summary>
	/// Summary description for DiskDetailsTreeView.
	/// </summary>
	public class DiskDetailsTreeView : TreeView
	{
		enum DiskDetails
		{
			Disk = 1,
			Directories = 2,
			Files = 4
		}
		public DiskDetailsTreeView()
		{
			//
			// TODO: Add constructor logic here
			//
			SetupImageList();
			arSelections = new ArrayList();
		}
		public void SetType(int nInfo)
		{
			m_nInfoType = nInfo;
		}
		private int m_nInfoType;
		private int m_nLastDirInfoCnt = 0;
		
		ArrayList arSelections;

		public ArrayList GetSelections()
		{
			return arSelections;
		}

		public void SetupImageList()
		{
			ImageList = new ImageList();
			ImageList.Images.Add(new Bitmap(GetType(), "FLOPPY.BMP"));
			ImageList.Images.Add(new Bitmap(GetType(), "CLSDFOLD.BMP"));
			ImageList.Images.Add(new Bitmap(GetType(), "OPENFOLD.BMP"));
		}
		public void AddDrives()
		{
			String[] strDrives;
			strDrives = Directory.GetLogicalDrives();
			foreach(String strDrv in strDrives)
			{
				TreeNode node = new TreeNode(strDrv, 0, 0);
				this.Nodes.Add(node);
			}
		}
			// fill the directories on expansion
		public void AddDirectories(TreeNode node)
		{
			string          strPath = node.FullPath;
			DirectoryInfo   dirinfo = new DirectoryInfo(strPath);
			DirectoryInfo[] adirinfo;
			this.BeginUpdate();
			try
			{
				adirinfo = dirinfo.GetDirectories();
				if(adirinfo.GetLength(0) > 0)
				{
					if(m_nLastDirInfoCnt == 0)
					{
						m_nLastDirInfoCnt = adirinfo.GetLength(0);
					}
					else
					{
						if(adirinfo.GetLength(0) != m_nLastDirInfoCnt)
						{
							node.Nodes.Clear();
						}
					}
				}
			}
			catch
			{
				return;
			}

			foreach (DirectoryInfo di in adirinfo)
			{
				TreeNode tnDir = new TreeNode(di.Name, 1, 2);
				node.Nodes.Add(tnDir);
			}
			this.EndUpdate();
		}
		protected override void OnBeforeSelect(TreeViewCancelEventArgs e)
		{
			base.OnBeforeSelect(e);
			if(e.Action != TreeViewAction.Unknown)
				AddDirectories(e.Node);
		}
		protected override void OnAfterCheck(TreeViewEventArgs e)
		{
			base.OnAfterCheck(e);
			string strNode = new String( e.Node.FullPath.ToCharArray());
			if(strNode.Length > 0 && e.Action != TreeViewAction.Unknown)
			{
				arSelections.Sort();
				if(e.Node.Checked == true)
				{
					if(arSelections.Contains(strNode) == false)
						arSelections.Add(strNode);
				}
				else
				{
					if(arSelections.Contains(strNode) == true)
					{
						arSelections.Remove(strNode);
					}
				}
				//((Form1)this.Parent).UpdateSearchLocations(arSelections);
			}
		}
	}
}
