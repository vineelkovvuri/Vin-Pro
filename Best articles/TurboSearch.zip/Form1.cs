using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Runtime.InteropServices;
using Microsoft.Win32;


namespace TurboFindFiles
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	///
	using LabelClass = System.Windows.Forms.Label;

	public class Form1 : System.Windows.Forms.Form
	{
		private LabelClass label1;
		private LabelClass label2;
		private LabelClass label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.RadioButton rbOther;
		private System.Windows.Forms.RadioButton rbNormal;
		private System.Windows.Forms.CheckBox cbTemporary;
		private System.Windows.Forms.CheckBox cbDirectory;
		private System.Windows.Forms.CheckBox cbCompressed;
		private System.Windows.Forms.CheckBox cbArchive;
		private System.Windows.Forms.CheckBox cbReadOnly;
		private System.Windows.Forms.CheckBox cbHidden;
		private System.Windows.Forms.CheckBox cbSystem;
		private System.Windows.Forms.TextBox txtContainsText;
		private System.Windows.Forms.TextBox txtSearchCriteria;
		//private System.Windows.Forms.ListView lstVwFilesFound;
		private ListViewEx lstVwFilesFound;
		//private System.ComponentModel.IContainer components;

		private Image[] imageArr;
		private Searcher search;
		private Font drawFont;
		private SolidBrush drawBrush;
		private StringFormat drawFormat;
		private ArrayList FileArray;
		private System.Windows.Forms.StatusBar StatusBar;
		private DiskDetailsTreeView TreeVwLookin;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.LinkLabel linkLabel1;
		private System.Windows.Forms.Button butSearchNow;
		private System.Windows.Forms.Button butStopSearch;
		private int FormsOldWidth;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.DateTimePicker dateTimePicker3;
		private System.Windows.Forms.DateTimePicker dateTimePicker2;
		private System.Windows.Forms.DateTimePicker dateTimePicker4;

		public FileAttributesDlg FileAttribsDlg;
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			rbNormal.Checked = true;
			rbOther.Checked = false;
			search = new Searcher();
			FileAttribsDlg = new FileAttributesDlg();
			EnableFileAttributesBoxes(false);
			InitLookin();
			// Create font and brush.
			drawFont = new Font("Arial", 8);
			drawBrush = new SolidBrush(Color.Black);    
			// Set format of string.
			drawFormat = new StringFormat();
			FileArray = new ArrayList();
			//set the images to be used by my combobox
			imageArr = new Image[4];
			// set the listview columns
			String[] colNames = {"Name", "In Folder"};		// these are the fixed columns
			SetListviewColumns(colNames);
			FormsOldWidth = this.Size.Width;
			// attach delegate for events
			search.ParseFileMsg += new Searcher.ParsingFileEventHandler(DisplaySearcherMsg);
			search.LocatedFileMsg += new Searcher.LocatedFileEventHandler(DisplayMatch);
			search.CompletedMsg += new Searcher.CompletedEventHandler(CompletedEventHandler);
			FileAttribsDlg.ColumnsChangedMsg += new FileAttributesDlg.UpdateEventHandler(OnColumsChangedHandler);
		}
		void OnColumsChangedHandler(object sender, FileAttributesDlg.LstUpdateArgs arg)
		{
			bool bFound;
			foreach(FileAttributesDlg.ColumnState Column in arg.Columns)
			{
				bFound = false;
				for(int nColIndx = 0; nColIndx < lstVwFilesFound.Columns.Count; ++nColIndx)
				{
					ColumnHeader head = lstVwFilesFound.Columns[nColIndx];
					if(head.Text == Column.strName)
					{
						bFound = true;
						if(Column.bDisplay == false)
							lstVwFilesFound.Columns.RemoveAt(nColIndx);
						break;
					}
				}
				if(bFound == false)
				{
					if(Column.bDisplay == true)
					{
						ColumnHeader hdr = new ColumnHeader();
						hdr.Text = Column.strName;	
						lstVwFilesFound.Columns.Add(hdr);
					}
				}
			}
		}

		private void SetListviewColumns(String[] colNames)
		{
			foreach(String strColName in colNames)
			{
				lstVwFilesFound.AddColumn(strColName);
			}
		}
		private void InitLookin()
		{
			TreeVwLookin.AddDrives();
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/*protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}*/

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lstVwFilesFound = new TurboFindFiles.ListViewEx();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.cbReadOnly = new System.Windows.Forms.CheckBox();
			this.cbTemporary = new System.Windows.Forms.CheckBox();
			this.cbArchive = new System.Windows.Forms.CheckBox();
			this.cbDirectory = new System.Windows.Forms.CheckBox();
			this.txtContainsText = new System.Windows.Forms.TextBox();
			this.rbOther = new System.Windows.Forms.RadioButton();
			this.rbNormal = new System.Windows.Forms.RadioButton();
			this.label8 = new System.Windows.Forms.Label();
			this.cbCompressed = new System.Windows.Forms.CheckBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.butStopSearch = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.TreeVwLookin = new TurboFindFiles.DiskDetailsTreeView();
			this.cbHidden = new System.Windows.Forms.CheckBox();
			this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			this.butSearchNow = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.StatusBar = new System.Windows.Forms.StatusBar();
			this.txtSearchCriteria = new System.Windows.Forms.TextBox();
			this.cbSystem = new System.Windows.Forms.CheckBox();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// lstVwFilesFound
			// 
			this.lstVwFilesFound.AccessibleName = "FilesFound";
			this.lstVwFilesFound.BackColor = System.Drawing.SystemColors.Desktop;
			this.lstVwFilesFound.Location = new System.Drawing.Point(484, 24);
			this.lstVwFilesFound.Name = "lstVwFilesFound";
			this.lstVwFilesFound.Size = new System.Drawing.Size(320, 288);
			this.lstVwFilesFound.Sorting = System.Windows.Forms.SortOrder.Ascending;
			this.lstVwFilesFound.TabIndex = 8;
			this.lstVwFilesFound.View = System.Windows.Forms.View.Details;
			this.lstVwFilesFound.DragDrop += new System.Windows.Forms.DragEventHandler(this.LVDragDrop);
			this.lstVwFilesFound.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.LvColumnClicked);
			this.lstVwFilesFound.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.LVItemDrag);
			// 
			// linkLabel1
			// 
			this.linkLabel1.Location = new System.Drawing.Point(548, 8);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(100, 16);
			this.linkLabel1.TabIndex = 33;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "(Show Columns)";
			this.linkLabel1.Click += new System.EventHandler(this.OnShowColumns);
			this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			// 
			// cbReadOnly
			// 
			this.cbReadOnly.Location = new System.Drawing.Point(160, 216);
			this.cbReadOnly.Name = "cbReadOnly";
			this.cbReadOnly.Size = new System.Drawing.Size(104, 16);
			this.cbReadOnly.TabIndex = 26;
			this.cbReadOnly.Text = "ReadOnly";
			// 
			// cbTemporary
			// 
			this.cbTemporary.Location = new System.Drawing.Point(160, 120);
			this.cbTemporary.Name = "cbTemporary";
			this.cbTemporary.Size = new System.Drawing.Size(104, 16);
			this.cbTemporary.TabIndex = 18;
			this.cbTemporary.Text = "Temporary";
			this.cbTemporary.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// cbArchive
			// 
			this.cbArchive.Location = new System.Drawing.Point(160, 168);
			this.cbArchive.Name = "cbArchive";
			this.cbArchive.Size = new System.Drawing.Size(104, 16);
			this.cbArchive.TabIndex = 23;
			this.cbArchive.Text = "Archive";
			// 
			// cbDirectory
			// 
			this.cbDirectory.Location = new System.Drawing.Point(160, 136);
			this.cbDirectory.Name = "cbDirectory";
			this.cbDirectory.Size = new System.Drawing.Size(104, 16);
			this.cbDirectory.TabIndex = 21;
			this.cbDirectory.Text = "Directory";
			// 
			// txtContainsText
			// 
			this.txtContainsText.Location = new System.Drawing.Point(8, 72);
			this.txtContainsText.Name = "txtContainsText";
			this.txtContainsText.Size = new System.Drawing.Size(264, 20);
			this.txtContainsText.TabIndex = 3;
			this.txtContainsText.Text = "";
			// 
			// rbOther
			// 
			this.rbOther.Location = new System.Drawing.Point(88, 120);
			this.rbOther.Name = "rbOther";
			this.rbOther.Size = new System.Drawing.Size(64, 16);
			this.rbOther.TabIndex = 20;
			this.rbOther.Text = "Other";
			this.rbOther.CheckedChanged += new System.EventHandler(this.rbOther_CheckedChanged);
			// 
			// rbNormal
			// 
			this.rbNormal.Location = new System.Drawing.Point(16, 120);
			this.rbNormal.Name = "rbNormal";
			this.rbNormal.Size = new System.Drawing.Size(64, 16);
			this.rbNormal.TabIndex = 19;
			this.rbNormal.Text = "Normal";
			this.rbNormal.CheckedChanged += new System.EventHandler(this.rbNormal_CheckedChanged);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(188, 184);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(16, 20);
			this.label8.TabIndex = 33;
			this.label8.Text = "&&";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// cbCompressed
			// 
			this.cbCompressed.Location = new System.Drawing.Point(160, 184);
			this.cbCompressed.Name = "cbCompressed";
			this.cbCompressed.Size = new System.Drawing.Size(104, 16);
			this.cbCompressed.TabIndex = 24;
			this.cbCompressed.Text = "Compressed";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(484, 8);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(72, 16);
			this.label4.TabIndex = 9;
			this.label4.Text = "Files Found:";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 152);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(96, 16);
			this.label5.TabIndex = 27;
			this.label5.Text = "Created between:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 184);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(96, 16);
			this.label6.TabIndex = 32;
			this.label6.Text = "Modified between:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(188, 152);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(16, 20);
			this.label7.TabIndex = 33;
			this.label7.Text = "&&";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// butStopSearch
			// 
			this.butStopSearch.Location = new System.Drawing.Point(96, 320);
			this.butStopSearch.Name = "butStopSearch";
			this.butStopSearch.TabIndex = 28;
			this.butStopSearch.Text = "Stop Search";
			this.butStopSearch.Click += new System.EventHandler(this.StopSearch_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(168, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Search for files or folder names:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 56);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "Containing Text:";
			this.label2.Click += new System.EventHandler(this.label2_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(308, 8);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Look in:";
			// 
			// TreeVwLookin
			// 
			this.TreeVwLookin.CheckBoxes = true;
			this.TreeVwLookin.Location = new System.Drawing.Point(308, 24);
			this.TreeVwLookin.Name = "TreeVwLookin";
			this.TreeVwLookin.Size = new System.Drawing.Size(168, 224);
			this.TreeVwLookin.TabIndex = 32;
			// 
			// cbHidden
			// 
			this.cbHidden.Location = new System.Drawing.Point(160, 200);
			this.cbHidden.Name = "cbHidden";
			this.cbHidden.Size = new System.Drawing.Size(104, 16);
			this.cbHidden.TabIndex = 25;
			this.cbHidden.Text = "Hidden";
			// 
			// dateTimePicker4
			// 
			this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePicker4.Location = new System.Drawing.Point(104, 184);
			this.dateTimePicker4.Name = "dateTimePicker4";
			this.dateTimePicker4.Size = new System.Drawing.Size(84, 20);
			this.dateTimePicker4.TabIndex = 36;
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePicker1.Location = new System.Drawing.Point(204, 152);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(84, 20);
			this.dateTimePicker1.TabIndex = 34;
			// 
			// dateTimePicker3
			// 
			this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePicker3.Location = new System.Drawing.Point(104, 152);
			this.dateTimePicker3.Name = "dateTimePicker3";
			this.dateTimePicker3.Size = new System.Drawing.Size(84, 20);
			this.dateTimePicker3.TabIndex = 35;
			// 
			// dateTimePicker2
			// 
			this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePicker2.Location = new System.Drawing.Point(204, 184);
			this.dateTimePicker2.Name = "dateTimePicker2";
			this.dateTimePicker2.Size = new System.Drawing.Size(84, 20);
			this.dateTimePicker2.TabIndex = 34;
			// 
			// butSearchNow
			// 
			this.butSearchNow.Location = new System.Drawing.Point(8, 320);
			this.butSearchNow.Name = "butSearchNow";
			this.butSearchNow.TabIndex = 7;
			this.butSearchNow.Text = "Search Now";
			this.butSearchNow.Click += new System.EventHandler(this.SearchNow_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.dateTimePicker1,
																					this.label8,
																					this.label7,
																					this.label6,
																					this.label5,
																					this.dateTimePicker3,
																					this.dateTimePicker2,
																					this.dateTimePicker4});
			this.groupBox1.Location = new System.Drawing.Point(8, 96);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(292, 216);
			this.groupBox1.TabIndex = 27;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "File Attributes";
			// 
			// StatusBar
			// 
			this.StatusBar.Location = new System.Drawing.Point(0, 348);
			this.StatusBar.Name = "StatusBar";
			this.StatusBar.Size = new System.Drawing.Size(822, 20);
			this.StatusBar.TabIndex = 30;
			this.StatusBar.Text = "status";
			// 
			// txtSearchCriteria
			// 
			this.txtSearchCriteria.Location = new System.Drawing.Point(8, 24);
			this.txtSearchCriteria.Name = "txtSearchCriteria";
			this.txtSearchCriteria.Size = new System.Drawing.Size(264, 20);
			this.txtSearchCriteria.TabIndex = 1;
			this.txtSearchCriteria.Text = "";
			this.txtSearchCriteria.TextChanged += new System.EventHandler(this.txtSearchCriteria_TextChanged);
			// 
			// cbSystem
			// 
			this.cbSystem.Location = new System.Drawing.Point(160, 152);
			this.cbSystem.Name = "cbSystem";
			this.cbSystem.Size = new System.Drawing.Size(104, 16);
			this.cbSystem.TabIndex = 22;
			this.cbSystem.Text = "System";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Desktop;
			this.ClientSize = new System.Drawing.Size(822, 368);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.linkLabel1,
																		  this.TreeVwLookin,
																		  this.StatusBar,
																		  this.cbReadOnly,
																		  this.cbHidden,
																		  this.cbCompressed,
																		  this.cbArchive,
																		  this.cbSystem,
																		  this.cbDirectory,
																		  this.rbOther,
																		  this.rbNormal,
																		  this.cbTemporary,
																		  this.label4,
																		  this.lstVwFilesFound,
																		  this.label3,
																		  this.txtContainsText,
																		  this.label2,
																		  this.txtSearchCriteria,
																		  this.label1,
																		  this.groupBox1,
																		  this.butStopSearch,
																		  this.butSearchNow});
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(980, 396);
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(830, 396);
			this.Name = "Form1";
			this.Text = "TurboSerach";
			this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void label2_Click(object sender, System.EventArgs e)
		{

		}

		private void checkBox1_CheckedChanged(object sender, System.EventArgs e)
		{

		}

		public void UpdateSearchLocations(ArrayList arr)
		{
			txtSearchCriteria.Clear();
			string NewText = "";
			foreach(string strDir in arr)
			{
				NewText += strDir + ";";
			}
			if(NewText.Length > 0)
			{
				NewText = NewText.Substring(0, NewText.Length - 1);
				txtSearchCriteria.Text = NewText;
			}
		}
		private void rbNormal_CheckedChanged(object sender, System.EventArgs e)
		{
			EnableFileAttributesBoxes(false);
		}

		private void SearchNow_Click(object sender, System.EventArgs e)
		{
			FileAttributes attribs = GetMatchAttributes();
			lstVwFilesFound.Items.Clear();
			ArrayList arr = TreeVwLookin.GetSelections();
			if(txtSearchCriteria.Text.Length == 0)
			{
				MessageBox.Show("Please enter a search criteria", "Argument error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			butSearchNow.Enabled = false;
			search.BeginSearch(arr, txtSearchCriteria.Text, attribs, txtContainsText.Text, ref FileArray );
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{

		}

		private void rbOther_CheckedChanged(object sender, System.EventArgs e)
		{
			EnableFileAttributesBoxes(true);
		}
		private void EnableFileAttributesBoxes(bool bState)
		{
			cbTemporary.Enabled = bState;
			cbDirectory.Enabled = bState;
			cbCompressed.Enabled = bState;
			cbArchive.Enabled = bState;
			cbReadOnly.Enabled = bState;
			cbHidden.Enabled = bState;
			cbSystem.Enabled = bState;
		}
		private FileAttributes GetMatchAttributes()
		{
			FileAttributes attribs = 0;
			if(rbNormal.Checked == true)
			{
				attribs  |= FileAttributes.Normal;
			}
			else
			{
				if(cbTemporary.Checked == true)
					attribs |= FileAttributes.Archive;
				if(cbDirectory.Checked == true)
					attribs |= FileAttributes.Directory;
				if(cbCompressed.Checked == true)
					attribs |= FileAttributes.Compressed;
				if(cbArchive.Checked == true)
					attribs |= FileAttributes.Archive;
				if(cbReadOnly.Checked == true)
					attribs |= FileAttributes.ReadOnly;
				if(cbHidden.Checked == true)
					attribs |= FileAttributes.Hidden;
				if(cbSystem.Checked == true)
					attribs |= FileAttributes.System;
			}
			return attribs;
		}

		private void txtSearchCriteria_TextChanged(object sender, System.EventArgs e)
		{

		}

		private void StopSearch_Click(object sender, System.EventArgs e)
		{
			if(butSearchNow.Enabled == false)
			{
				search.EndSerach();
				butSearchNow.Enabled = true;
				
				string strInfo = "Found " + search.nMatchingFiles.ToString() + " Matches.";
				KeepUserInformed(strInfo);
			}
		}

		private void Form1_SizeChanged(object sender, System.EventArgs e)
		{
			int FormsCurrentWidth = this.Size.Width;
			Rectangle lstvwBnd = lstVwFilesFound.Bounds;
			lstVwFilesFound.SetBounds(lstvwBnd.X, lstvwBnd.Y, lstvwBnd.Width +(FormsCurrentWidth - FormsOldWidth),lstvwBnd.Height);
			FormsOldWidth = FormsCurrentWidth;
		}
		public void KeepUserInformed(String strInfo)
		{
			StatusBar.Text = strInfo;
		}
		// Event handling routines
		void DisplaySearcherMsg(object ob, Searcher.FileParseEventArgs args)
		{
			StatusBar.Text = "Searching Folder : " + args.strMsg;
		}
		void DisplayMatch(object sender, Searcher.FileMatchEventArgs args)
		{
			lstVwFilesFound.AddRow(args.node);
		}
		void CompletedEventHandler(object sender)
		{
			butSearchNow.Enabled = true;
			string strInfo = "Found " + search.nMatchingFiles.ToString() + " Matches.";
			KeepUserInformed(strInfo);
		}
	//
		private void LvColumnClicked(object sender, System.Windows.Forms.ColumnClickEventArgs e)
		{
			lstVwFilesFound.SortOnColumn(e.Column);
		}

		private void LVDragDrop(object sender, System.Windows.Forms.DragEventArgs e)
		{

		}

		private void LVItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
		{
			DataObject ob = new DataObject();
			ListViewItem item = (ListViewItem)e.Item;
			string strFullPath;
			strFullPath = item.SubItems[1].Text + "\\"  + item.SubItems[0].Text;
			ob.SetData(DataFormats.FileDrop, true, strFullPath);
			lstVwFilesFound.DoDragDrop(ob, DragDropEffects.Copy);
		}

		private void textBox3_TextChanged(object sender, System.EventArgs e)
		{

		}

		private void OnShowColumns(object sender, System.EventArgs e)
		{
			FileAttribsDlg.ShowDialog();

		}

		private void linkLabel1_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{

		}
	}
}
