using System;
using System.Windows.Forms;
using System.Collections;

namespace TurboFindFiles
{
	/// <summary>
	/// Summary description for ListItemCompare.
	/// </summary>
	public class ListItemCompare : IComparer
	{
		public ListItemCompare(ListViewEx parent)
		{
			//
			// TODO: Add constructor logic here
			//
			Parent = parent;
		}
		public int Compare(object first, object second)		// first second are of types ListViewItem
		{
			if(SortColumn == -1)							// essentially don't do any sorting
				return 0;
			ListViewItem firstItem = (ListViewItem)first;
			ListViewItem secondItem = (ListViewItem)second;
			string colFirst;
			string colSecond; 
			if(firstItem.SubItems.Count <= SortColumn)
				return 0;
			colFirst = firstItem.SubItems[SortColumn].Text;
			colSecond = secondItem.SubItems[SortColumn].Text;
			return colFirst.CompareTo(colSecond) * toggleSort;				// for toggling the sort
		}

		

		private int SortColumn = -1;
		private int toggleSort = 1;
		private ListViewEx Parent;

		public int sortColumn
		{
			get
			{
				return SortColumn;
			}
			set
			{
				toggleSort *= -1;
				SortColumn = value;
			}
		}
	}
}
