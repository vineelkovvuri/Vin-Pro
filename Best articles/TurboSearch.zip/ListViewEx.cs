using System;
using System.Windows.Forms;
namespace TurboFindFiles
{
	/// <summary>
	/// Summary description for ListViewEx.
	/// </summary>
	

	public class ListViewEx : System.Windows.Forms.ListView
	{
		private void InitializeComponent()
		{

		}
		public ListItemCompare comparer;
		public ListViewEx()
		{
			//
			// TODO: Add constructor logic here
			//
			comparer = new ListItemCompare(this);
			this.ListViewItemSorter = comparer;

			
		}

		public void SortOnColumn(int nColumn)
		{
			comparer.sortColumn = nColumn;
			this.Sort();
		}

		public void AddColumn(string Name)
		{
			System.Windows.Forms.ColumnHeader colHeader = new System.Windows.Forms.ColumnHeader();
			colHeader.Text = Name;
			this.Columns.Add(colHeader);
		}

		public void AddRow(CFileNode node)
		{
			int n = 2;
			string[] SubItems = new string[Columns.Count];
			SubItems[0] = node.strFileName;
			SubItems[1] = node.strFolder;
				// now for the optional columns
			foreach(System.Windows.Forms.ColumnHeader colHeader in this.Columns)
			{
				if(colHeader.Text == "Size(Bytes)" && n < Columns.Count)
				{
					SubItems[n++] = node.Size.ToString();
				}
				else if(colHeader.Text == "Created" && n < Columns.Count)
				{
					SubItems[n++] = node.DateCreated.ToShortDateString();
				}
				else if(colHeader.Text == "Last Modified" && n < Columns.Count)
				{
					SubItems[n++] = node.LastModified.ToShortDateString();
				}
			}			
			System.Windows.Forms.ListViewItem row = new System.Windows.Forms.ListViewItem(SubItems);
			row.Tag = SubItems;
			this.Items.Add(row);
		}
	}
}
