using System;
using Microsoft.Win32;      // per la lettura/scrittura nei registri
using System.Windows.Forms; // per la funzione MessageBox

namespace CSharp_ScreenSaver
{
	public struct Propriet�ScreenSaver
	{
		public string PercorsoImmagini;
		public string FormatoImmagini;
		public string Carattere;
		public int ColoreSfondo;
		public int ColoreTesto;
	}

	/* **************************************************************************
	 * **************************************************************************/

	public class ImpostazioniProgramma
	{
		public Propriet�ScreenSaver Carica()
		{
			// Inizializzazione della struttura
			Propriet�ScreenSaver mieImpostazioni = new Propriet�ScreenSaver();

			// Apertura della chiava di registro
			RegistryKey rk = Registry.LocalMachine ;
			RegistryKey sk1 = rk.OpenSubKey("SOFTWARE\\CSharpSlideShow_ScreenSaver");
			// Se non esiste -> impostazioni di default
			if ( sk1 == null )
			{
				mieImpostazioni.PercorsoImmagini = "C:\\" ; 
				mieImpostazioni.FormatoImmagini = "GIF";
				mieImpostazioni.Carattere = "Tahoma";
				mieImpostazioni.ColoreSfondo = 10;
				mieImpostazioni.ColoreTesto = 9;
			}
			else
			{
				try 
				{
					// Altrimenti prelevo i valori salvati
					mieImpostazioni.PercorsoImmagini = (string)sk1.GetValue("percorso");
					mieImpostazioni.FormatoImmagini  = (string)sk1.GetValue("formato");
					mieImpostazioni.Carattere	     = (string)sk1.GetValue("font");
					mieImpostazioni.ColoreSfondo	 = int.Parse((string)sk1.GetValue("bcolor"));
					mieImpostazioni.ColoreTesto		 = int.Parse((string)sk1.GetValue("fcolor"));
				}
				catch (Exception e)
				{
					MessageBox.Show("Errore nel caricamento delle impostazioni:\n\n" 
									+ e.Message,
									"Errore"
									,MessageBoxButtons.OK
									,MessageBoxIcon.Error);
				}
			}
			// ritorna la struttura valorizzata
			return mieImpostazioni;
		}	

		/* **************************************************************************
		 * **************************************************************************/

		public void Salva(Propriet�ScreenSaver miePropriet�)
		{
			try
			{
				// Inizializzazione
				RegistryKey rk = Registry.LocalMachine ;
				// Apertura
				RegistryKey sk1 = rk.OpenSubKey("SOFTWARE\\CSharpSlideShow_ScreenSaver");
				// Se esiste gi� la cancello per poi ricrearla
				if ( sk1 != null )
					rk.DeleteSubKeyTree("SOFTWARE\\CSharpSlideShow_ScreenSaver");
				// Viene creata
				sk1 = rk.CreateSubKey("SOFTWARE\\CSharpSlideShow_ScreenSaver");

				// Salvataggio
				sk1.SetValue("bcolor"   , Convert.ToSingle(miePropriet�.ColoreSfondo));
				sk1.SetValue("fcolor"   , Convert.ToSingle(miePropriet�.ColoreTesto));
				sk1.SetValue("percorso" , miePropriet�.PercorsoImmagini);
				sk1.SetValue("formato"  , miePropriet�.FormatoImmagini);
				sk1.SetValue("font"     , miePropriet�.Carattere);	
			}
			catch (Exception e)
			{
				MessageBox.Show("Errore nel salvataggio delle impostazioni:\n\n"
								+ e.Message,
								"Errore"
								,MessageBoxButtons.OK
								,MessageBoxIcon.Error);
			}
		}
	}
}
