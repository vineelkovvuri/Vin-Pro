using System;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace CSharp_ScreenSaver
{
	public class ClasseSfogliaCartelle : FolderNameEditor
	{
		FolderNameEditor.FolderBrowser miaFinestra;

		public void Inizializza()
		{
			miaFinestra = new FolderNameEditor.FolderBrowser();
		}

		public string SfogliaCartelle(string titolo)
		{
			string mioPercorso;

			miaFinestra.Description = titolo;
			// Visualizzo la finestra
			miaFinestra.ShowDialog();
			// Prelevo il percorso selezionato
			mioPercorso = miaFinestra.DirectoryPath;
			// Controllo se devo aggiungere "\" alla fine
			if (mioPercorso.Length > 0) 
			{
				if (mioPercorso.Substring((mioPercorso.Length - 1),1) != "\\") 
					mioPercorso += "\\";
			}
			// Rispedisco al mittente
			return mioPercorso;
		}
		
		~ClasseSfogliaCartelle()
		{
			miaFinestra.Dispose(); // Rilascio delle risorse
		}
	}
}
