using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using System.Threading;
using System.Runtime.InteropServices ; // per il DllImport

namespace CSharp_ScreenSaver
{
	public class Anteprima
	{
		/* Struttura rettangolare, 
		 * serve per la finestra di Anteprima */
		private struct RECT
		{
			public int left;
			public int top;
			public int right;
			public int bottom;

			public int Left
			{ get { return left; } }
			public int Top
			{ get { return top; } }
			public int Right
			{ get { return right; } }
			public int Bottom
			{ get { return bottom; } }
			public int Width
			{ get { return right-left; } }
			public int Height
			{ get { return bottom - top; } }
		}
 
		/* un po' di API */
		[DllImport("user32.dll")]
		private static extern bool GetClientRect(IntPtr hWnd, ref RECT rect);

		[DllImport("user32.DLL",EntryPoint="IsWindowVisible")]
		private static extern bool IsWindowVisible(IntPtr hWnd);

		private Icon miaIcona;
		private Color coloreTesto;
		private Color coloreSfondo;
		private System.Drawing.Color[] colorArray = new System.Drawing.Color[14]; 

		/* propriet� - finestraAnteprima - 
		 * in questo modo � possibile assegnare un valore
		 * ad una variabile static da una classe esterna */
		private static IntPtr finestraAnteprima;		
		public IntPtr FinestraAnteprima
		{
			get	{ return finestraAnteprima;	}
			set	{ finestraAnteprima = value; }
		}

		public void InizializzaAnteprima()
		{
			// Prelevo l'icona
			Form1 miaForm = new Form1();
			miaIcona = miaForm.Icon;
			miaForm.Dispose();

			// Valorizzazione dell'array dei colori
			colorArray[0] = Color.YellowGreen;
			colorArray[1] = Color.Blue;
			colorArray[2] = Color.Chocolate;
			colorArray[3] = Color.DarkGreen;
			colorArray[4] = Color.Gold;
			colorArray[5] = Color.Khaki;
			colorArray[6] = Color.MintCream;
			colorArray[7] = Color.LightCoral;
			colorArray[8] = Color.Purple;
			colorArray[9] = Color.Yellow;
			colorArray[10] = Color.Black;
			colorArray[11] = Color.Azure;
			colorArray[12] = Color.Firebrick;
			colorArray[13] = Color.DarkMagenta;
			// Prelevo il colore dello sfondo e del testo
			Propriet�ScreenSaver miePropriet�	  = new Propriet�ScreenSaver();
			ImpostazioniProgramma mieImpostazioni = new ImpostazioniProgramma();
			// Carica le impostazioni 		
			miePropriet� = mieImpostazioni.Carica();
			// Assegno alla form:
			coloreTesto  = colorArray[miePropriet�.ColoreTesto];
			coloreSfondo = colorArray[miePropriet�.ColoreSfondo];

			// Inizializzazione del timer
			System.Timers.Timer mioTimer = new System.Timers.Timer();
			mioTimer.Interval = 1000 ;
			// Ne associo l'evento
			mioTimer.Elapsed += new System.Timers.ElapsedEventHandler(VisualizzaAnteprima);
			// Si parte!
			mioTimer.Start();
			/* ne fermo per poco l'esecuzione in modo da essere sicuro che
			 * la funzione IsWindowVisible ritorni il valore giusto
			 * siccome non � molto veloce */
			Thread.Sleep(200);
			/* se la finestra � stata chiusa oppure � stata aperta 
			 * la finestra delle opzioni il programma esce, 
			 * (IsWindowVisible(FinestraAnteprima) == false) */
			while (IsWindowVisible(FinestraAnteprima) == true)
			{
				/* in questo modo non occupa tutte le risorse
				 * continuando a ciclare, esegue il controllo ogni 200 ms */
				Thread.Sleep(200);

				/* ovviamente quando esce viene chiuso 
				 * automaticamente anche il timer */
			}
		}

		private void VisualizzaAnteprima(object sender, System.Timers.ElapsedEventArgs e)
		{
			RECT rc = new RECT();
			if (GetClientRect(finestraAnteprima, ref rc))
			{
				// Sfondo
				Graphics.FromHwnd(finestraAnteprima).Clear(coloreSfondo);
				// Disegna l'icona
				Graphics.FromHwnd(finestraAnteprima).DrawIcon(miaIcona,
															 (rc.Right / 2) - 16,
															 (rc.Bottom / 2) - 24);
				// Scrive l'ora
				Graphics.FromHwnd(finestraAnteprima).DrawString(DateTime.Now.ToLongTimeString(), 
																new Font("Thaoma",8) , 
																new SolidBrush(coloreTesto) , 
																new Point((rc.Right / 2)-24,(rc.Bottom / 2)+18), 
																StringFormat.GenericDefault);
			}
			// Serve fare altro ?
			Application.DoEvents();
		}
	}
}
