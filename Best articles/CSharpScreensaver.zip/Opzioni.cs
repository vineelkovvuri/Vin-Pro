using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace CSharp_ScreenSaver
{
	/// <summary>
	/// Summary description for Options.
	/// </summary>
	///
	public class Options : System.Windows.Forms.Form
	{
		private System.Windows.Forms.FontDialog fontDialog1;
		private System.Windows.Forms.Label label4;
		ArrayList colorArray = new ArrayList() ;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox cmbColoreTesto;
		private System.Windows.Forms.ComboBox cmbColoreSfondo;
		private System.Windows.Forms.TextBox txtPercorso;
		private System.Windows.Forms.Button cmdOk;
		private System.Windows.Forms.Button cmdChiudi;
		private System.Windows.Forms.ToolTip toolTip;
		private System.Windows.Forms.ComboBox cmbFormato;
		private System.Windows.Forms.Button cmdCarattere;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label lblCarattere;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button cmdCambiaCartella;
		private System.Windows.Forms.LinkLabel lblMandaEmail;
		private System.ComponentModel.IContainer components;

		public Options()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		} 

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Options));
			this.fontDialog1 = new System.Windows.Forms.FontDialog();
			this.label4 = new System.Windows.Forms.Label();
			this.cmdChiudi = new System.Windows.Forms.Button();
			this.cmdOk = new System.Windows.Forms.Button();
			this.cmbColoreTesto = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.cmdCambiaCartella = new System.Windows.Forms.Button();
			this.cmbFormato = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.txtPercorso = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.cmbColoreSfondo = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.cmdCarattere = new System.Windows.Forms.Button();
			this.lblMandaEmail = new System.Windows.Forms.LinkLabel();
			this.label3 = new System.Windows.Forms.Label();
			this.lblCarattere = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label4
			// 
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Location = new System.Drawing.Point(16, 96);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(80, 23);
			this.label4.TabIndex = 5;
			this.label4.Text = "Colore sfondo:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// cmdChiudi
			// 
			this.cmdChiudi.BackColor = System.Drawing.Color.Transparent;
			this.cmdChiudi.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.cmdChiudi.Image = ((System.Drawing.Bitmap)(resources.GetObject("cmdChiudi.Image")));
			this.cmdChiudi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.cmdChiudi.Location = new System.Drawing.Point(312, 40);
			this.cmdChiudi.Name = "cmdChiudi";
			this.cmdChiudi.Size = new System.Drawing.Size(104, 23);
			this.cmdChiudi.TabIndex = 4;
			this.cmdChiudi.Text = "Chiudi";
			this.toolTip.SetToolTip(this.cmdChiudi, "Chiude la finestra");
			this.cmdChiudi.Click += new System.EventHandler(this.cmdChiudi_Click);
			// 
			// cmdOk
			// 
			this.cmdOk.BackColor = System.Drawing.Color.Transparent;
			this.cmdOk.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.cmdOk.Image = ((System.Drawing.Bitmap)(resources.GetObject("cmdOk.Image")));
			this.cmdOk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.cmdOk.Location = new System.Drawing.Point(312, 8);
			this.cmdOk.Name = "cmdOk";
			this.cmdOk.Size = new System.Drawing.Size(104, 23);
			this.cmdOk.TabIndex = 4;
			this.cmdOk.Text = "OK";
			this.toolTip.SetToolTip(this.cmdOk, "Salva le impostazioni e chiude la finestra");
			this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
			// 
			// cmbColoreTesto
			// 
			this.cmbColoreTesto.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.cmbColoreTesto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbColoreTesto.Location = new System.Drawing.Point(104, 128);
			this.cmbColoreTesto.Name = "cmbColoreTesto";
			this.cmbColoreTesto.Size = new System.Drawing.Size(104, 21);
			this.cmbColoreTesto.TabIndex = 15;
			this.toolTip.SetToolTip(this.cmbColoreTesto, "Seleziona il colore del testo");
			this.cmbColoreTesto.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cmbColoreTesto_DrawItem);
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Location = new System.Drawing.Point(16, 128);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(80, 23);
			this.label6.TabIndex = 14;
			this.label6.Text = "Colore testo :";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.Color.Transparent;
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.cmdCambiaCartella,
																					this.cmbFormato,
																					this.label5,
																					this.txtPercorso,
																					this.label2});
			this.groupBox1.Location = new System.Drawing.Point(8, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(290, 80);
			this.groupBox1.TabIndex = 18;
			this.groupBox1.TabStop = false;
			// 
			// cmdCambiaCartella
			// 
			this.cmdCambiaCartella.BackColor = System.Drawing.Color.Transparent;
			this.cmdCambiaCartella.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.cmdCambiaCartella.Image = ((System.Drawing.Bitmap)(resources.GetObject("cmdCambiaCartella.Image")));
			this.cmdCambiaCartella.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.cmdCambiaCartella.Location = new System.Drawing.Point(176, 20);
			this.cmdCambiaCartella.Name = "cmdCambiaCartella";
			this.cmdCambiaCartella.Size = new System.Drawing.Size(104, 20);
			this.cmdCambiaCartella.TabIndex = 17;
			this.cmdCambiaCartella.Text = "Cambia";
			this.toolTip.SetToolTip(this.cmdCambiaCartella, "Chiude la finestra");
			this.cmdCambiaCartella.Click += new System.EventHandler(this.cmdCambiaCartella_Click);
			// 
			// cmbFormato
			// 
			this.cmbFormato.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbFormato.Location = new System.Drawing.Point(71, 48);
			this.cmbFormato.Name = "cmbFormato";
			this.cmbFormato.Size = new System.Drawing.Size(105, 21);
			this.cmbFormato.TabIndex = 16;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(9, 20);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(56, 16);
			this.label5.TabIndex = 15;
			this.label5.Text = "Percorso :";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// txtPercorso
			// 
			this.txtPercorso.Location = new System.Drawing.Point(71, 20);
			this.txtPercorso.Name = "txtPercorso";
			this.txtPercorso.ReadOnly = true;
			this.txtPercorso.Size = new System.Drawing.Size(105, 20);
			this.txtPercorso.TabIndex = 14;
			this.txtPercorso.Text = "C:\\";
			this.toolTip.SetToolTip(this.txtPercorso, "Indicare qui il percorso da dove iniziare la ricerca delle immagini");
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 22);
			this.label2.TabIndex = 10;
			this.label2.Text = "Formato:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// cmbColoreSfondo
			// 
			this.cmbColoreSfondo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.cmbColoreSfondo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbColoreSfondo.Location = new System.Drawing.Point(104, 96);
			this.cmbColoreSfondo.Name = "cmbColoreSfondo";
			this.cmbColoreSfondo.Size = new System.Drawing.Size(104, 21);
			this.cmbColoreSfondo.TabIndex = 9;
			this.toolTip.SetToolTip(this.cmbColoreSfondo, "Seleziona il colore dello sfondo");
			this.cmbColoreSfondo.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cmbColoreSfondo_DrawItem);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(16, 184);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(216, 16);
			this.label1.TabIndex = 20;
			this.label1.Text = "Screen Saver realizzato in C# da";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// cmdCarattere
			// 
			this.cmdCarattere.BackColor = System.Drawing.Color.Transparent;
			this.cmdCarattere.Location = new System.Drawing.Point(272, 128);
			this.cmdCarattere.Name = "cmdCarattere";
			this.cmdCarattere.Size = new System.Drawing.Size(104, 23);
			this.cmdCarattere.TabIndex = 4;
			this.cmdCarattere.Text = "Cambia carattere";
			this.toolTip.SetToolTip(this.cmdCarattere, "Modifica il carattere");
			this.cmdCarattere.Click += new System.EventHandler(this.cmdCarattere_Click);
			// 
			// lblMandaEmail
			// 
			this.lblMandaEmail.BackColor = System.Drawing.Color.Transparent;
			this.lblMandaEmail.Image = ((System.Drawing.Bitmap)(resources.GetObject("lblMandaEmail.Image")));
			this.lblMandaEmail.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.lblMandaEmail.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.lblMandaEmail.Location = new System.Drawing.Point(240, 184);
			this.lblMandaEmail.Name = "lblMandaEmail";
			this.lblMandaEmail.Size = new System.Drawing.Size(128, 16);
			this.lblMandaEmail.TabIndex = 25;
			this.lblMandaEmail.TabStop = true;
			this.lblMandaEmail.Text = "Francesco Natali";
			this.lblMandaEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.toolTip.SetToolTip(this.lblMandaEmail, "Per domande e suggerimenti scrivimi !");
			this.lblMandaEmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblMandaEmail_LinkClicked);
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Location = new System.Drawing.Point(216, 96);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(80, 23);
			this.label3.TabIndex = 21;
			this.label3.Text = "Carattere:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblCarattere
			// 
			this.lblCarattere.BackColor = System.Drawing.Color.Transparent;
			this.lblCarattere.Location = new System.Drawing.Point(304, 96);
			this.lblCarattere.Name = "lblCarattere";
			this.lblCarattere.Size = new System.Drawing.Size(112, 23);
			this.lblCarattere.TabIndex = 22;
			this.lblCarattere.Text = "miocarattere";
			this.lblCarattere.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// groupBox2
			// 
			this.groupBox2.BackColor = System.Drawing.Color.Transparent;
			this.groupBox2.Location = new System.Drawing.Point(8, 168);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(408, 8);
			this.groupBox2.TabIndex = 26;
			this.groupBox2.TabStop = false;
			// 
			// Options
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackgroundImage = ((System.Drawing.Bitmap)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(426, 207);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.groupBox2,
																		  this.lblMandaEmail,
																		  this.lblCarattere,
																		  this.label3,
																		  this.label1,
																		  this.groupBox1,
																		  this.cmbColoreTesto,
																		  this.label6,
																		  this.cmdCarattere,
																		  this.label4,
																		  this.cmdChiudi,
																		  this.cmdOk,
																		  this.cmbColoreSfondo});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Options";
			this.Opacity = 0.89999997615814209;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Opzioni :: Slide show screen saver con C #";
			this.Load += new System.EventHandler(this.Options_Load);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void cmdCarattere_Click(object sender, System.EventArgs e)
		{
			FontDialog fnt = new FontDialog();
			fnt.AllowSimulations = true;
			fnt.ShowEffects = false;
			if ( fnt.ShowDialog() == DialogResult.OK ) 
			{
				lblCarattere.Text = fnt.Font.Name.ToString() ; 
			}
		}

		private void Options_Load(object sender, System.EventArgs e)
		{
			colorArray.Add(new SolidBrush(Color.YellowGreen));	cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.Blue));			cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.Chocolate));	cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.DarkGreen));	cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.Gold));			cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.Khaki));		cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.MintCream));	cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.LightCoral));	cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.Purple));		cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.Yellow));		cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.Black));		cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.Azure));		cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.Firebrick));	cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");
			colorArray.Add(new SolidBrush(Color.DarkMagenta));	cmbColoreSfondo.Items.Add("");cmbColoreTesto.Items.Add("");

			// Popolo la combo
			string[] MioFormato = {"PNG","JPG","GIF","BMP"};
			cmbFormato.Items.AddRange(MioFormato);

			// Inizializzazione
			Propriet�ScreenSaver miePropriet�	  = new Propriet�ScreenSaver();
			ImpostazioniProgramma mieImpostazioni = new ImpostazioniProgramma();
			// Carica le impostazioni (testo da visualizzare, colore, ...)			
			miePropriet� = mieImpostazioni.Carica();
			// Assegno alla form:
			cmbColoreSfondo.SelectedIndex = miePropriet�.ColoreSfondo;
			cmbColoreTesto.SelectedIndex  = miePropriet�.ColoreTesto;
			txtPercorso.Text			  = miePropriet�.PercorsoImmagini;
			cmbFormato.Text				  = miePropriet�.FormatoImmagini;
			lblCarattere.Text			  = miePropriet�.Carattere;
		}

		/**************************************************************************
		 *				 Esce salvando gli eventuali cambiamenti                  *
		 **************************************************************************/ 
		private void cmdOk_Click(object sender, System.EventArgs e)
		{
			// Inizializzazione
			Propriet�ScreenSaver miePropriet�	  = new Propriet�ScreenSaver();
			ImpostazioniProgramma mieImpostazioni = new ImpostazioniProgramma();
			// Valorizzo la struttura
			miePropriet�.ColoreSfondo		=	cmbColoreSfondo.SelectedIndex;
			miePropriet�.ColoreTesto		=	cmbColoreTesto.SelectedIndex;
			miePropriet�.PercorsoImmagini	=	txtPercorso.Text.ToString();
			miePropriet�.FormatoImmagini	=	cmbFormato.Text.ToString();
			miePropriet�.Carattere			=	lblCarattere.Text.ToString();
			// Salvataggio
			mieImpostazioni.Salva(miePropriet�);
			// Esco
			this.Dispose();
		}

		/**************************************************************************
		 *				Esce senza salvare eventuali cambiamenti                  *
		 **************************************************************************/ 
		private void cmdChiudi_Click(object sender, System.EventArgs e)
		{
			this.Dispose();
		}

		/*********/ 

		private void cmbColoreSfondo_DrawItem(object sender, System.Windows.Forms.DrawItemEventArgs e)
		{
			// Funzione per disegnare rettangoli all'interno della combobox
			ColoriInCombo(e);
		}

		private void cmbColoreTesto_DrawItem(object sender, System.Windows.Forms.DrawItemEventArgs e)
		{
			// Funzione per disegnare rettangoli all'interno della combobox
			ColoriInCombo(e);
		}

		private void ColoriInCombo(System.Windows.Forms.DrawItemEventArgs e)
		{
			// Prelevo l'oggetto graphics
			Graphics g = e.Graphics ;

			// Prelevo i bordi del rettangolo che andr� a riempire
			Rectangle r = e.Bounds ;
			
			if ( e.Index >= 0 ) 
			{
				Rectangle rd = r ; 
				rd.Width = rd.Right ;
				r.X = rd.Right ; 

				// Creo l'oggetto brush con il colore determinato dall'indice di posizionamento
				SolidBrush b = (SolidBrush)colorArray[e.Index];
				// Riempio il rettangolo con il brush appena creato
				g.FillRectangle(b  , rd);

				// Draw the rectangle
				e.Graphics.DrawRectangle(new Pen(new SolidBrush(Color.Black), 2 ), r );

				if ( e.State == ( DrawItemState.NoAccelerator | DrawItemState.NoFocusRect))
				{
					// if the item is not selected draw it with a different color
					e.Graphics.FillRectangle(new SolidBrush(Color.White) , r);
					e.DrawFocusRectangle();
				}
				else
				{
					// if the item is selected draw it with a different color
					e.Graphics.FillRectangle(new SolidBrush(Color.LightBlue) , r);
					e.DrawFocusRectangle();
				}
			}
		}

		private void cmdCambiaCartella_Click(object sender, System.EventArgs e)
		{
			string mioPercorso;

			ClasseSfogliaCartelle miaFinestra = new ClasseSfogliaCartelle();
			miaFinestra.Inizializza();
			mioPercorso = miaFinestra.SfogliaCartelle("Seleziona una cartella contenente immagini");
			if (mioPercorso.Length > 0) 
				txtPercorso.Text = mioPercorso; 
		}

		/**************************************************************************
		 *			Avvia il programma di default di posta elettronica			  *
		 **************************************************************************/ 
		private void lblMandaEmail_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start("mailto:francesco.natali@email.it");
		}
	}
}
