/********************************************
 * Programma realizzato da Francesco Natali *
 ********************************************/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Text; 
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Threading;
using System.Timers; 
using System.IO;
			
namespace CSharp_ScreenSaver
{
	public class Form1 : System.Windows.Forms.Form
	{
		// variabili
		private System.Timers.Timer timer1=null;
		private static IntPtr parent = new IntPtr(0);

		// per le immagini
		private string[] FileImmagini = new string[2000];
		private int TotaleImmagini = 0;
		private int NumImgVisualizzata = 0;		
		private System.Drawing.Color[] colorArray = new System.Drawing.Color[14];
		private System.Windows.Forms.Label lblData;
		private System.Windows.Forms.Label lblOra;
		private System.Windows.Forms.PictureBox imgQuadro;
		private string formatoImmagini;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			// Valorizzazione dell'array dei colori
			colorArray[0] = Color.YellowGreen;
			colorArray[1] = Color.Blue;
			colorArray[2] = Color.Chocolate;
			colorArray[3] = Color.DarkGreen;
			colorArray[4] = Color.Gold;
			colorArray[5] = Color.Khaki;
			colorArray[6] = Color.MintCream;
			colorArray[7] = Color.LightCoral;
			colorArray[8] = Color.Purple;
			colorArray[9] = Color.Yellow;
			colorArray[10] = Color.Black;
			colorArray[11] = Color.Azure;
			colorArray[12] = Color.Firebrick;
			colorArray[13] = Color.DarkMagenta;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Rilascio di tutte le risorse usate
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.timer1 = new System.Timers.Timer();
			this.lblData = new System.Windows.Forms.Label();
			this.lblOra = new System.Windows.Forms.Label();
			this.imgQuadro = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.timer1)).BeginInit();
			this.SuspendLayout();
			// 
			// timer1
			// 
			this.timer1.SynchronizingObject = this;
			this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(this.timer1_Elapsed);
			// 
			// lblData
			// 
			this.lblData.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lblData.BackColor = System.Drawing.Color.Transparent;
			this.lblData.ForeColor = System.Drawing.Color.Black;
			this.lblData.Name = "lblData";
			this.lblData.Size = new System.Drawing.Size(336, 40);
			this.lblData.TabIndex = 1;
			this.lblData.Text = "sto";
			this.lblData.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// lblOra
			// 
			this.lblOra.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.lblOra.BackColor = System.Drawing.Color.Transparent;
			this.lblOra.ForeColor = System.Drawing.Color.Black;
			this.lblOra.Location = new System.Drawing.Point(0, 224);
			this.lblOra.Name = "lblOra";
			this.lblOra.Size = new System.Drawing.Size(336, 40);
			this.lblOra.TabIndex = 2;
			this.lblOra.Text = "caricando...";
			this.lblOra.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// imgQuadro
			// 
			this.imgQuadro.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.imgQuadro.BackColor = System.Drawing.Color.Transparent;
			this.imgQuadro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.imgQuadro.Cursor = System.Windows.Forms.Cursors.Hand;
			this.imgQuadro.Location = new System.Drawing.Point(16, 48);
			this.imgQuadro.Name = "imgQuadro";
			this.imgQuadro.Size = new System.Drawing.Size(304, 168);
			this.imgQuadro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.imgQuadro.TabIndex = 3;
			this.imgQuadro.TabStop = false;
			this.imgQuadro.Click += new System.EventHandler(this.imgQuadro_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(14, 32);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(224)), ((System.Byte)(224)));
			this.ClientSize = new System.Drawing.Size(336, 266);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.imgQuadro,
																		  this.lblOra,
																		  this.lblData});
			this.Font = new System.Drawing.Font("Arial", 20.25F, (System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.ForeColor = System.Drawing.Color.White;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimizeBox = false;
			this.Name = "Form1";
			this.ShowInTaskbar = false;
			this.TopMost = true;
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
			((System.ComponentModel.ISupportInitialize)(this.timer1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		///    MAIN
		/// </summary>
		[STAThread]
		static void Main() 
		{
			// Riempio l'array con i parametri che mi vengono passati
			string[] cmdList = Environment.CommandLine.Split(' ');
			
			/* il primo sar� sempre il nome del file, incluso 
			 * il suo percorso completo, il secondo sar� la modalit� di avvio:
			 *		/s -> avvio normale
			 *		/p -> avvio nella finestra delle propriet� dello schermo
			 *		/c -> � richiesta la finestra delle opzioni
			 * il terzo, nel caso di '/p', sar� il puntatore 
			 * alla finestra di visualizzazione */
			
			/* per test: 
			string s = "";
			for (int i = 0; i < cmdList.Length;i++)
				s += cmdList[i].ToString() + " ";
			MessageBox.Show(s.ToString(),"Parametri!"); */

			// � stato chiamato "manualmente" ? 
			if (cmdList[1] ==  "-") 
			{
				// Avvio lo screen-saver
				Application.Run(new Form1());
				return;
			}

			/* in che caso sono:
			 * utilizzo Substring perch� nel caso di '/c' non � a s� stante,
			 * nel senso che � nella forma << mioscrsvr.scr /c:123456 >>, 
			 * quindi devo separare i primi due caratteri. */
			switch (cmdList[1].Substring(0,2).ToString())
			{
				case "/c":
					// visualizzo la finestra delle opzioni
					Application.Run(new Options());
					return;
				case "/p":
					Anteprima miaAnteprima = new Anteprima();
					// prelevo l'indirizzo della finestra di anteprima
					parent = (IntPtr) uint.Parse(cmdList[2]);
					miaAnteprima.FinestraAnteprima = parent;
					// Inizializzo il thread per l'attesa mentre carica le immagini
					Thread MioThread = new Thread(new ThreadStart(miaAnteprima.InizializzaAnteprima));
					// Avvio il thread
					MioThread.Start();
					return;
				default:
					// Avvio lo screen-saver chiamando la Form1
					// (viene eseguita la Form1_Load)
					Application.Run(new Form1());
					break;
			}
		}

		/* **************************************************************************
		 * **************************************************************************/
		private void Form1_Load(object sender, System.EventArgs e)
		{		
			// Inizializzazione
			Propriet�ScreenSaver miePropriet� = new Propriet�ScreenSaver();
			ImpostazioniProgramma mieImpostazioni = new ImpostazioniProgramma();
			// Carica le impostazioni (testo da visualizzare, colore, ...)			
			miePropriet� = mieImpostazioni.Carica();
			// Aggiornamento
			lblData.Font	  = new Font(miePropriet�.Carattere,20);
			lblData.ForeColor = colorArray[miePropriet�.ColoreTesto]; 
			lblOra.Font		  = new Font(miePropriet�.Carattere,20);
			lblOra.ForeColor  = colorArray[miePropriet�.ColoreTesto];
			this.BackColor	  = colorArray[miePropriet�.ColoreSfondo];
			formatoImmagini   = miePropriet�.FormatoImmagini;

			// Carico l'icona da visualizzare mentre carica
			Bitmap miaIcona = new Bitmap(System.Drawing.Bitmap.FromHicon(this.Icon.Handle));
			this.imgQuadro.Image = miaIcona;
			// inizio a caricare le immagini
			CaricaImmagini(miePropriet�.PercorsoImmagini);

			// inizializzo il timer
			timer1.Interval = 1000; // un secondo
			timer1.Start();
		}

		/* **************************************************************************
		 * **************************************************************************/
		private void Form1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{	
			ChiudiProgragramma(); //anche se lo fa da solo... (?)
		}

		private void Form1_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if ( e.KeyChar == 13 || e.KeyChar == 27 )
				ChiudiProgragramma();
		}

		private void imgQuadro_Click(object sender, System.EventArgs e)
		{
			ChiudiProgragramma();
		}

		/* **************************************************************************
		 * **************************************************************************/
		private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			// Ogni secondo aggiorno la form
			AggiornaForm();
		}

		/* **************************************************************************
		 * **************************************************************************/
		protected override void WndProc(ref Message m)
		{
			// Se arriva un ordine dell'alto...
			if ( m.Msg == 0x0082)
			{
				ChiudiProgragramma();
			}
			base.WndProc(ref m);
		}

		/* **************************************************************************
		 * **************************************************************************/
		private void CaricaImmagini(string Percorso)
		{
			try 
			{
				DirectoryInfo dirInfo = new DirectoryInfo(Percorso);
				foreach(FileInfo fileInfo in dirInfo.GetFiles("*." + formatoImmagini))
				{
					// Mi assicuro che il sistema non si blocchi durante il caricamento ;-)
					Application.DoEvents();
					// Carica l'immagine
					FileImmagini[TotaleImmagini]= fileInfo.FullName.ToString();
					// Aggiorno il contatore
					TotaleImmagini++;
					// Visualizza il nome dell'immagine che ha caricato
					lblData.Text = fileInfo.Name.ToString();
					lblOra.Text = TotaleImmagini.ToString();
					/*********************************************
					*				Ruota l'icona				 *
					*********************************************/ 
					this.imgQuadro.Image.RotateFlip(System.Drawing.RotateFlipType.Rotate90FlipNone);
					this.imgQuadro.Refresh();
				}

				// Chiamata ricorsiva per le sotto directory
				foreach(string SottoCartella in Directory.GetDirectories(Percorso))
				{
					CaricaImmagini(SottoCartella);
				}
			}
			catch 
			{
				/* se ad esempio si accede ad una cartella protetta
				 * viene generato un errore, ma il caricamento
				 * non deve fermarsi, quindi "return" ! */
				return; 
			}
		}

		/* **************************************************************************
		 * **************************************************************************/
		private void AggiornaForm()
		{
			// Data e Ora
			lblData.Text = " :: " + DateTime.Today.ToLongDateString() + " :: "; 
			lblOra.Text = " :: " + DateTime.Now.ToLongTimeString() + " :: "; 

			// Visualizzo l'immagine
			imgQuadro.Image = System.Drawing.Bitmap.FromFile(FileImmagini[NumImgVisualizzata]);
			// Incremento l'indice
			NumImgVisualizzata++;
			// Se le ho visualizzate tutte riparto da zero
			if (NumImgVisualizzata == TotaleImmagini)
			{
				NumImgVisualizzata = 0;
			}
		}

		/* **************************************************************************
		 * **************************************************************************/
		public void ChiudiProgragramma()
		{
			// Rilascia tutte le risorse
			this.Dispose(true);
			// Uscita
			Application.Exit();
		}
	}
}
