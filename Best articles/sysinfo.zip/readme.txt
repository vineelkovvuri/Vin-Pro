System Information Class.
DLL Version: 1.9XTb
Author: Tran Ngoc Tien
email: m_blue_bird@yahoo.com, cats@hn.fpt.vn(TTVNers only)
tel: (84-04) 090-225-704

Credit:
Here I want to express my gratitude 
to the friends who have tested the DLL 
on their systems and/or encouraged me 
to continue on this project.
---Name---------Email----------------------------Nation-----
Jan.Vangorp	<jan.vangorp@netropolix.be>	 Belgium
Egbert.Jansen 	<egbert.jansen@sensormedics.com> Netherlands
VHQ		<vhonguang@hn.fpt.vn>		 Vietnam
Xiaobin Li	<xiaobinl@wou.edu>		 China
TomArcher	<tarcher@mindspring.com>	 US
HaiNH		<honghainew@hn.fpt.vn>		 Vietnam
NguyenTrung	<nguyentrung_vnn@hotmail.com>	 US
------------------------------------------------------------

About this library:
*Yes, it's FREE! You can use it to reduce the headaches 
while fixing customer's problems. Just send me the name
of your application in case you find my lib is worthy.
*Goto: <http://www.codeguru.com/system> for the latest version.

Environment:
_Visual C++ 5.0.
_Windows 95/98.

How to use:
1_Just add the SysInfo.h into your project.
2_Add <path>TNTSI.lib into: Project/Settings/Link/Library modules.
3_Remember the line: #include "SysInfo.h" wherever you need.
4_In your class, add only two lines of code:
	Sysinfo si_object;
	CString m_info=si_object.TNTGetInfo();

 *********
 *  Q&A  *
 *********
 Q1_Heap/stack errors when I call TNTGetInfo()!
 A1_Since the DLL is in Release version, so _DO_NOT_ use it in your _Debug_
session. If you suspect smt wrong with the DLL, then run the demo to figure 
it out. And if the demo works, please don't email me about heap/stack errors
in the Debug version of your project.

 Q2_I don't want all the info!
 A2_Because I develop this library to help trouble shooting on customer's PC,
so one function is enough. The CString object is ready for printing, sending 
or saving these results.
 If you really want only some info, or want to display the result on fields, 
let's use the Mid/Find members of the CString class to extract the info you 
need. It's very easy because they are already sorted in categories.
 The other reason: if I add some dozens members/function to help you get every
information you need, one by one, then the size of the DLL will increase about
20Kilobytes or even more. Do you like that?

 Q3_"Where is the source?"
 A3_I have to read nearly one hundred emails with this subject. Please don't 
ask for the source, I don't want to give it now. And since it contains not 
only pure C++ code, you will have more things to do than press F7 to compile
your project.

 Q4_NT Problem ...
 A4_This version is aimed at Windows 9x environment. 
I'm thinking of developing a new version for NT later.

Anyother problem, feel free to contact me.
TNT