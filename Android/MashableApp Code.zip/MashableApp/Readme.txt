

The core object to hold the data from twitter(and also for other services) is encapsulated in to FeedDataObject
It contains following fields
	String title;
	String content;
	String date;		
	String statusText;    // include any additional information like feed posted username or any other custom information	
	String serviceType;   // indicates whether the service is twitter, linkedin facebook

My notion of feed is any of the following
tweet,facebook post,linkedin content, blog feeds

The above object is an in memory representation of each feed that is directly visible in the UI ( Check the screenshot )
	

The idea of the application is access the respective service and query the service for the required information based on the 
entered query word in settings page.

working

step 1: we pass the url to FeedHelper GetSource method this returns the source code of the url(may be JSON or xml)
step 2: we pass the above returned source code to respective parser class parse method for example incase of twitter
		we invoke TwitterFeedParser Class's parse method. This method know how to parse the twitter content and return 
		the results the form of list of FeedDataObjects.
step 3: Bind the returned results to the Main UI Listview control by calling 
		lvFeedList.setAdapter(new FeedListRowAdapter(MainActivity.this, listoffeeds));

		
--------------------------------------------------------------------
FeedDataObject.java
Contains above said object which will(should) hold data from various services
Please review the code 

FeedHelper.java
Contains code to connect a given url and retrieve its source code
supports both http and https urls

FeedListRowAdapter.java
Custom built Listview class which know how to talk to FeedDataObject and present it to the UI
Its basically an adapter between our data(returned in the form of list of FeedDataObjects) and
the UI
  
MainActivity.java
Main driver class which will run the application logic 
this is the place where above said step 1..3 will be run

SettingsActivity.java
Simple activity to store the query keyword
may have to modify if ur service need to store more complicated inputs
like bunch of blog feed urls....
This class also know how to stored the entered query keyword even after the app
is closed.

TwitterFeedParser.java
It know how to parse the twitter content and return that in the form of 
list of FeedDataObjects.
This is how you have to create parsers for ur own services.....


Hope you got an idea.......
Please read the code......I have commented it thoroughly

	
	