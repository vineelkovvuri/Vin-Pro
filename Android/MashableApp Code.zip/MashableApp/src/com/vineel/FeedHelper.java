package com.vineel;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.net.URLConnection;


/*
 *  FeedHelper helps us to connect to a given URL and 
 *  return the URL source code
 *  
 *  example in the case of twitter 
 *  URL is "http://search.twitter.com/search.json?q="+query+"&lang=en&rpp=10"
 *  returned value: JSON Source code
 *  
 *  PLEASE MAKE USE OF THIS HELPER TO CONNECT TO YOUR RESPECTIVE SERVICES
 *  ONLY THING REQUIRED IS U HAVE TO FIGURE OUT THE URL TO UR SERVICE
 */

public class FeedHelper {
	
	
	// this is to handle https urls
	static class MyAuthenticator extends Authenticator
	{
		protected PasswordAuthentication getPasswordAuthentication()
		{
			return new PasswordAuthentication ( "username", "password".toCharArray() );
		}
	}

	static {
		System.setProperty("http.proxyHost", "proxy.iiit.ac.in");
		System.setProperty("http.proxyPort", "8080");
	}

	// input: URL whose source code should be retrieved
	// input: if the url is https the ssl should be set to true
	// output: urls source code
	public static StringBuffer GetSource(String url,boolean ssl)
	{
		StringBuffer sb = new StringBuffer();
		try {
			URL google = new URL(url);
			URLConnection urlcon = google.openConnection();
			if(ssl){Authenticator.setDefault( new MyAuthenticator() );}
			BufferedReader in = new BufferedReader(new InputStreamReader(urlcon.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				sb.append(inputLine);
			}
			in.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb;
	}
}
