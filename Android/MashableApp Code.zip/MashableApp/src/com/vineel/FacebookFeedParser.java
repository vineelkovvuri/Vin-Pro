package com.vineel;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import android.util.Log;

public class FacebookFeedParser {
	public static List<FeedDataObject>  Parse(StringBuffer sb){
		List<FeedDataObject> feeds = null;
		try{
			feeds = new ArrayList<FeedDataObject>();
			String line = sb.toString();
			JSONObject jo = new JSONObject(line);
			JSONArray res  = (JSONArray) jo.get("data");
			for (int j = 0; j < res.length(); j++) {
				JSONObject result = (JSONObject) res.get(j);
				String date = result.optString("created_time");
				String fromUser = ((JSONObject)result.get("from")).optString("name");
				String title = result.optString("story");

				String content = result.optString("description");
				if(content == null || content.isEmpty()){
					
					content = result.optString("caption");
					content = content.substring(0,content.length()<160?content.length():160)+"...";
				}
				feeds.add(new FeedDataObject(title , content, date, fromUser, "facebook"));
				System.out.println(feeds.get(feeds.size()-1));
			}
		}catch(Exception e){
			Log.i("Places info:",e.getMessage());
		}
		return feeds;
	}
}
