package com.vineel;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


/*
 *  Implements settings page
 *  
 *  Contains a simple text field to accept query 
 *  and stores that in SharedPreferences Object
 *  
 *  The data in the object persist even after the 
 *  application is terminated 
 * 
 */

public class SettingsActivity extends Activity {

//	ListView lvServices = null;
//	String ServicesList[] = null;
	Button bSave = null;
	EditText etQuery = null;
	EditText etRSSLinks = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.settings);

		InitiateControls();

		//load existing query if available or else load the default query ( 'android' )
		SharedPreferences settings = getSharedPreferences("MashableApp", 0);
		etQuery.setText(settings.getString("query", "android"));
		etRSSLinks.setText(settings.getString("rsslinks", ""));
		//save the query 
		bSave.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				SharedPreferences settings = getSharedPreferences("MashableApp", 0);
				SharedPreferences.Editor editor = settings.edit();
				editor.putString("query", etQuery.getText().toString().trim());
				editor.putString("rsslinks", etRSSLinks.getText().toString().trim());
				editor.commit();
				
				Toast.makeText(SettingsActivity.this, "Settings Saved...", Toast.LENGTH_LONG).show();
				Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
				startActivity(intent);
			}
		});

	}


	private void InitiateControls() {
	//	Resources res = getResources();

		etQuery = (EditText)findViewById(R.id.etQuery);
		etRSSLinks = (EditText)findViewById(R.id.etRSSLinks);
		bSave = (Button)findViewById(R.id.bSave);

	}


}
