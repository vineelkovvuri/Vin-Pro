package com.vineel;

import java.util.ArrayList;
import java.util.StringTokenizer;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends Activity {

	Button bRefresh,bSettings;
	ListView lvFeedList = null;
	String query = "android";
	ArrayList<String> rsslinks = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		InitializeControls();
		
		
		//fired when refresh button is clicked
		bRefresh.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//start new async thread to fetch the data
				new BackgroundFetch().execute("");
			}
		});
		
		//Handler to invoke settings activity
		bSettings.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
				startActivity(intent);
			}
		});
	}

	/*
	 * If there are previous queries saved during last exit that will be
	 * returned or else default keyword 'android' is returned......
	 * so our results will be initially getting android feeds.
	 */
	private void LoadPreferences() {
		 SharedPreferences settings = getSharedPreferences("MashableApp", 0);
		 rsslinks = new ArrayList<String>();
		 query = settings.getString("query", "android");
		 String rssEditTextContent = settings.getString("rsslinks", "");
		 
		 if(!rssEditTextContent.trim().equals("")){
			 StringTokenizer st = new StringTokenizer(rssEditTextContent,"|");
			 while(st.hasMoreTokens()) { 
				 rsslinks.add(st.nextToken());
			 }
		 }
		 System.out.println(rsslinks);
		 System.out.println(query);
		 
	}
	//initialize UI controls
	private void InitializeControls() {
		lvFeedList = (ListView) findViewById(R.id.lvFeedList);
		lvFeedList.setClickable(true);
		bRefresh = (Button) findViewById(R.id.bRefresh);
		bSettings= (Button) findViewById(R.id.bSettings);
		
	}
	
	   									//	param , progess, result
	class BackgroundFetch extends AsyncTask<String, String, ArrayList<FeedDataObject>>{
		
		@Override
		protected ArrayList<FeedDataObject> doInBackground(String... arg0) {
			
			
			//final list of feed entries
			ArrayList<FeedDataObject> feeds = new ArrayList<FeedDataObject>();
			
			publishProgress("Loading Queries & Blog Entries....");
			LoadPreferences();		//load preferences of the application saved during previous exit
			
			
			publishProgress("Fetching From Twitter....");
			//Invoke each service like the below
			feeds.addAll(TwitterFeedParser.Parse(FeedHelper.GetSource("http://search.twitter.com/search.json?q="+query+"&lang=en&rpp=5", false)));
			
			// THIS IS THE PLACE YOU NEED TO INVOKE YOUR SERVICES AS SHOWN AS THE ABOVE LINE
			// WHERE IN <Service>Parser.Parse Method will take a URL or bunch of URLS and 
			// return the list of feeds 
			// Example for facebook url may be facebook search url
			// return values may be FeedDataObject of posts related to the given query
			// similarly for blog feeds the input to the parser may be bunch of URLs
			// return values may be FeedDataObject of posts related to the given query
			publishProgress("Fetching From Facebook....");
			feeds.addAll(FacebookFeedParser.Parse(FeedHelper.GetSource("https://graph.facebook.com/search?q="+query+"&type=post&limit=5", true)));
			
			//for parsing blog feeds - each iteration fetch rss of a single blog
			//Toast.makeText(MainActivity.this, "Fetching Blogs...", Toast.LENGTH_LONG).show();
			for(String rsslink : rsslinks){
				publishProgress("Fetching From "+rsslink+"....");
				feeds.addAll(BlogFeedParser.Parse(FeedHelper.GetSource(rsslink, false)));
			}
		
			publishProgress("Mashable App"); 
			return feeds;
		}
		
		@Override
		protected void onPostExecute(ArrayList<FeedDataObject> result) {
			//once the list is populated with the feed objects publish to the main UI
			lvFeedList.setAdapter(new FeedListRowAdapter(MainActivity.this, result));
		}

		@Override
		protected void onProgressUpdate(String... values) {
			
			setTitle(values[0]);
			super.onProgressUpdate(values);
		}

	}
	
}