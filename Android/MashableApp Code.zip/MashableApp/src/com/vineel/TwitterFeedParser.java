package com.vineel;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import android.util.Log;
/*
 * This is class which is capable of parsing twitter JSON results 
 * into FeedDataObject Objects 
 * 
 * static Parse method is responsible to achieve this
 * 
 * You have to create your own parser to parse the results from the respective services
 */
public class TwitterFeedParser {
	
	//input: complete JSON source from the twitter for the given query 
	//output: list of parsed FeedDataObjects 
	public static List<FeedDataObject>  Parse(StringBuffer sb){
		List<FeedDataObject> feeds = null;
		try{
			feeds = new ArrayList<FeedDataObject>();
			String line = sb.toString();
			JSONObject jo = new JSONObject(line);
			JSONArray res  = (JSONArray) jo.get("results");
			for (int j = 0; j < res.length(); j++) {
				JSONObject result = (JSONObject) res.get(j);
				String date = result.optString("created_at");
				String fromUser = result.optString("from_user");
				String _title = result.optString("source");
//				.replace("&lt;", "").replace("href=&quot;", "").
//							   replace("&lt;", "").replace("&gt;", "").replace("rel=&quot;", "").
//							   replace("&quot;", "");
				String link ="";
				try{
				_title = _title.substring(_title.indexOf("http"));
				link = _title.substring(0,_title.indexOf("&quot"));
				_title = _title.substring(_title.indexOf("&quot"));
				_title = _title.substring(_title.indexOf("&gt;")+4);
				_title = _title.substring(0,_title.indexOf("&lt;"));
				
				link = link +" - "+_title;
				}catch(Exception e){
					link = _title.replace("&lt;", "").replace("href=&quot;", "").
							   replace("&lt;", "").replace("&gt;", "").replace("rel=&quot;", "").
							   replace("&quot;", "");
				}
				
				String content = result.optString("text");
				feeds.add(new FeedDataObject(link, content, date, fromUser, "twitter"));
				System.out.println(feeds.get(feeds.size()-1));
			}
		}catch(Exception e){
			Log.i("Places info:",e.getMessage());
		}
		return feeds;
	}
}
