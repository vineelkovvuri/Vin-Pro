package com.vineel;

import java.util.ArrayList;
import java.util.List;
/*
 * This is class which is capable of parsing Blog XML results 
 * into FeedDataObject Objects 
 * 
 * static Parse method is responsible to achieve this
 * 
 * You have to create your own parser to parse the results from the respective services
 */
public class BlogFeedParser {
	
	//input: complete XML source from the Blog for the given query 
	//output: list of parsed FeedDataObjects 
	public static List<FeedDataObject>  Parse(StringBuffer sb){
		FeedDataObject feed;
		List<FeedDataObject> feeds = null;
		try{
			feeds = new ArrayList<FeedDataObject>();
			String line = sb.toString();
			String fromUser = line.substring(line.indexOf("<title>"),line.indexOf("</title>")+8);
			fromUser = TrimTags(fromUser,"title");
			line = line.substring(line.indexOf("</title>")+8);
			int count = 5;
			while(line != null){

				if(line.indexOf("<item>") < 0 || count <= 0 )break;
				
				String item = line.substring(line.indexOf("<item>"),line.indexOf("</item>")+7);
				
				if(!"".equals(item)){
					
					String title = item.substring(item.indexOf("<title>"),item.indexOf("</title>")+8);
					title = TrimTags(title,"title");
					item = item.substring(item.indexOf("</title>")+8);
					
					String link = item.substring(item.indexOf("<link>"),item.indexOf("</link>")+7);
					link = TrimTags(link,"link");
					item = item.substring(item.indexOf("</link>")+7);
					
					String description = item.substring(item.indexOf("<description>"),item.indexOf("</description>")+14);
					description = TrimTags(description,"description");
					item = item.substring(item.indexOf("</description>")+14);
					
					String date = item.substring(item.indexOf("<pubDate>"),item.indexOf("</pubDate>")+10);
					date = TrimTags(date,"pubDate");
					item = item.substring(item.indexOf("</pubDate>")+10);
					
					
					feeds.add(feed = new FeedDataObject(title+" - "+link, description, date, fromUser, "rss"));
					count--;
					System.out.println(feed);
				}
				
				
				line = line.substring(line.indexOf("</item>")+7);
				
				
			}
	
		}catch(Exception e){
			e.printStackTrace();
		}
		return feeds;
	}

	private static String TrimTags(String str, String tag) {
		
		String line = str.substring(str.indexOf("<"+tag+">")+tag.length()+2, str.indexOf("</"+tag+">"));
		
		return line;
	}
}
