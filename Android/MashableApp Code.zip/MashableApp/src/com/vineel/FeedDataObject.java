package com.vineel;

/*
 *  main object which can encapsulate various services data 
 *  
 *  So this abstract away the common properties from all the services.
 *  like 
 * 	String title;
	String content;
	String date;
	String statusText;
	String serviceType;
 */

public class FeedDataObject {
	String title;
	String content;
	String date;
	String statusText;
	String serviceType;
	public FeedDataObject(String title, String content, String date,
			String statusText, String feedType) {
		super();
		this.title = title;
		this.content = content;
		this.date = date;
		this.statusText = statusText;
		this.serviceType = feedType;
	}
	
	//this is for debugging purposes......
	@Override
	public String toString() {
		return "FeedDataObject ["
				+ (serviceType != null ? "feedType=" + serviceType : "")
				+ (title != null ? "title=" + title + ", " : "")
				+ (content != null ? "content=" + content + ", " : "")
				+ (date != null ? "date=" + date + ", " : "")
				+ (statusText != null ? "statusText=" + statusText + ", " : "")
				 + "]";
	}
	
	
}
