package com.vineel;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


/*
 *  Custom built List view object
 *  
 *  input takes list of FeedDataObjects  and render them to UI
 *  
 *  YOU NEED NOT PEEP OR PONDER WITH THIS FILE!!
 *   
 */


public class FeedListRowAdapter extends BaseAdapter {


	private Context context;
	private List<FeedDataObject> feeds;

	public FeedListRowAdapter(Context context, List<FeedDataObject> feeds) {
		super();
		this.context = context;
		this.feeds = feeds;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return feeds.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return feeds.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	//binds FeedDataObject to the UI Listview entry
	@Override
	public View getView(int position, View convertView, ViewGroup arg2) {
		FeedDataObject entry = feeds.get(position);
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.feedrowitem, null);
		}

		if(entry.serviceType.equals("twitter")){
			ImageView ivServiceIcon = (ImageView) convertView.findViewById(R.id.ivServiceIcon);
			ivServiceIcon.setImageResource(R.drawable.twitter_32);
		}
		else if(entry.serviceType.equals("facebook")){
			ImageView ivServiceIcon = (ImageView) convertView.findViewById(R.id.ivServiceIcon);
			ivServiceIcon.setImageResource(R.drawable.facebook_32);
		}
		else if(entry.serviceType.equals("rss")){
			ImageView ivServiceIcon = (ImageView) convertView.findViewById(R.id.ivServiceIcon);
			ivServiceIcon.setImageResource(R.drawable.rss_32);
		}

		TextView tvFeedTitle = (TextView) convertView.findViewById(R.id.tvFeedTitle);
		tvFeedTitle.setText(entry.title);

		TextView tvFeedContent = (TextView) convertView.findViewById(R.id.tvFeedContent);
		tvFeedContent.setText(entry.content);

		TextView tvTimeStamp = (TextView) convertView.findViewById(R.id.tvTimeStamp);
		tvTimeStamp.setText(entry.date);

		TextView tvStatusText = (TextView) convertView.findViewById(R.id.tvStatusText);
		tvStatusText.setText(entry.statusText);


		return convertView;
	}

}
