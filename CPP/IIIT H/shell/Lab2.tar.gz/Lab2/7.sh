#!/bin/bash



whoami
date






