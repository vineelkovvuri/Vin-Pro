

area=float(raw_input('Enter the area:'))
side=float(raw_input('Enter the side:'))

print area/side


