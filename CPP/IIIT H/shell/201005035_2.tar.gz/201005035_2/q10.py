
queue = []

def enqueue(element):
    queue.append(element)

def dequeue():
    if len(queue) >= 0:
        return queue.pop(0)
    else:
        return None    

def printq():
    print queue

def isempty():
    return len(queue) == 0


