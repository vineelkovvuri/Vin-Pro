
def rev(fp):
    c = fp.read(1)
    if c:
        rev(fp)
        out.write(c)

filename = raw_input("Enter the filename")
fp = open(filename, "r") 
out = open(filename+"_reverse.txt", "w") 
rev(fp)


