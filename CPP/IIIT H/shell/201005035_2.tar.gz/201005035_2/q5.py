
str= raw_input('Enter the string:')

l=len(str)

i=1

while i<l:  # substring length loop
    j=0 
    while j<l:
        substr = str[j:j+i]
        if len(substr) == i:
            print substr,
        j=j+1
    i=i+1


