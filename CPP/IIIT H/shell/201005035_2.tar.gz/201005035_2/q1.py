n=int(raw_input('Enter the number:'))
count=0
i=1
while 1:
	if(count == n):
		break
	square=i*i
	if(square % 2 != 0):
		print square
		count=count+1
	i=i+1
