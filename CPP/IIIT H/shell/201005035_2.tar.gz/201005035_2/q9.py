
stack = []

def push(element):
    stack.append(element)

def pop():
    if len(stack) >= 0:
        return stack.pop(len(stack) - 1)
    else:
        return None    

def top():
    return stack[-1]

def isempty():
    return len(stack) == 0


