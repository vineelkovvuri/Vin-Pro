
n=int(raw_input('Enter the input:'))

a,b=0,1
if n==1:
    print 0,
elif n==2:
    print 0,1,   
else:
    print 0,1,
    i=2
    while i<n:
        c = a+b
        print c ,
        a=b
        b=c
        i=i+1

    
