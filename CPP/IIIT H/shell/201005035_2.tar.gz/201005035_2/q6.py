import sys

def addEntry():
    entry = {}
    name = raw_input("Enter the name:");
    entry['name'] = name
    phno = raw_input("Enter the phone number:");
    entry['phno'] = phno
    email = raw_input("Enter the email:");
    entry['email'] = email
    address = raw_input("Enter the Address:");
    entry['address'] = address    
    phonebook.append(entry)


def search():
    name = raw_input("Enter the name:");
    for entry in phonebook:
        if entry['name'] == name:
            print entry['name']
            print entry['phno']
            print entry['email']
            print entry['address']            
            break
    else:
        print "Error not found the phone book"       

def delete():
    name = raw_input("Enter the name:");
    for entry in phonebook:
        if entry['name'] == name:
            phonebook.remove(entry)
            break
    else:
        print "Error not found the phone book"       


def showAll():
    for entry in phonebook:
        print entry['name']
        print entry['phno']
        print entry['email']
        print entry['address']           
        print "\n" 

phonebook = []

while 1:
    print "1.Add"
    print "2.Search"
    print "3.Delete"
    print "4.Show All"
    print "5.Exit"

    choice = raw_input("Enter the number:")
    if choice == "1":
        addEntry()
    elif choice == "2":
        search()
    elif choice == "3":
        delete()
    elif choice == "4":
        showAll()
    elif choice == "5":
        sys.exit(0)
    
    
    
