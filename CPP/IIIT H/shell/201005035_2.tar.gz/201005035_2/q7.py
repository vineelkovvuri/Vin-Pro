


def prime(num):
    div=2
    while div<=num/2.0:
        if num%div == 0:
            print num
            return 0
        div = div + 1
    if div>num/2.0:
        return 1



n=int(raw_input("Enter the number:"))
print filter(prime,range(1,n))               

    
