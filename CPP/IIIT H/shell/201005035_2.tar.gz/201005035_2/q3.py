
str=raw_input('Enter the input:')

revstr = str[::-1]

if revstr == str :
    print str+" is palendrome"
else:
    print str+" not a palendrome"

