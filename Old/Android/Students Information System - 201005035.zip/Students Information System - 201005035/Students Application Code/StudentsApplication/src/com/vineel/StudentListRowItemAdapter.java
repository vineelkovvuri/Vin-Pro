package com.vineel;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RadioButton;
import android.widget.TextView;

public class StudentListRowItemAdapter extends BaseAdapter {

	private Context context;
	private List<StudentDataObject> students;
	android.view.View.OnClickListener onclick = null;
	public StudentListRowItemAdapter(Context context, List<StudentDataObject> students,android.view.View.OnClickListener onclick) {
		super();
		this.context = context;
		this.students = students;
		this.onclick = onclick;
	}

	@Override
	public int getCount() {

		return students.size();
	}

	@Override
	public Object getItem(int position) {

		return students.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	//Gets called for each entry in the data list passed to the adapter
	public View getView(int position, View convertView, ViewGroup viewGroup) {
		StudentDataObject entry = students.get(position);
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.studentslistrowitem, null);
		}


		TextView tvName = (TextView) convertView.findViewById(R.id.tvName);
		tvName.setText(entry.name);

		TextView tvRollNo = (TextView) convertView.findViewById(R.id.tvRollNo);
		tvRollNo.setText(entry.rollno);

		TextView tvLocation = (TextView) convertView.findViewById(R.id.tvLocation);
		tvLocation.setText(entry.location);

		TextView tvPhone = (TextView) convertView.findViewById(R.id.tvPhone);
		tvPhone.setText(entry.phone);

		TextView tvEmail = (TextView) convertView.findViewById(R.id.tvEmail);
		tvEmail.setText(entry.email);

		RadioButton rbSelected = (RadioButton) convertView.findViewById(R.id.rbSelected);
		rbSelected.setFocusable(false);
		rbSelected.setClickable(false);
		
		
		
		convertView.setTag(entry);

		convertView.setOnClickListener(onclick);

		return convertView;
	}

	



}
