package com.vineel;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ListStudentActivity extends Activity {

	ListView lvStudentsList = null;
	ArrayList<StudentDataObject> students = null;
	OnClickListener onclick = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.liststudentsactivity);
		InitializeControls();

		//Fetch all students from students table and bind them to listview
		students = DatabaseHelper.GetStudentRecords(this, DatabaseHelper.GetAllStudentsSQL);
		if(students.size() > 0)
			lvStudentsList.setAdapter(new StudentListRowItemAdapter(this, students, onclick));

	}

	StudentDataObject selectedStudent;
	private void InitializeControls() {
		lvStudentsList = (ListView) findViewById(R.id.lvStudentsList);
		lvStudentsList.setClickable(true);
		onclick = new OnClickListener() {
			View previousSelectedView = null;
			@Override
			public void onClick(View v) {
				if(previousSelectedView != v){
					if(previousSelectedView != null){
						RadioGroup prevGP = (RadioGroup) previousSelectedView.findViewById(R.id.rbGroup);
						prevGP.clearCheck();
					}
					RadioButton rb = (RadioButton) v.findViewById(R.id.rbSelected);
					rb.setChecked(true);
					selectedStudent = (StudentDataObject) v.getTag();
					System.out.println(selectedStudent);
					previousSelectedView = v;
				}
			}
		};
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu); 
		getMenuInflater().inflate(R.menu.studentsreportmenu, menu); 
		return true;
	}
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		if(selectedStudent != null){
			String SQL = "";
			switch(item.getItemId()){
			case R.id.miStudentEdit:
				 Intent intent = new Intent(this, StudentsActivity.class);
				 intent.putExtra("StartedFromListStudentActivity",true);
				 intent.putExtra("rollno", selectedStudent.rollno);
				 intent.putExtra("name", selectedStudent.name);
				 intent.putExtra("location", selectedStudent.location);
				 intent.putExtra("phone", selectedStudent.phone);
				 intent.putExtra("email", selectedStudent.email);
				 startActivity(intent);
				break;
			case R.id.miStudentDelete:
				SQL = "DELETE FROM StudentDetails WHERE rollno='"+selectedStudent.rollno+"';";
				DatabaseHelper.DeleteRecord(this, SQL);
				Toast.makeText(this, "Selected Record Deleted....", Toast.LENGTH_LONG);
				//If record is deleted reload the data
				//Fetch all students from students table and bind them to listview
				students = DatabaseHelper.GetStudentRecords(this, DatabaseHelper.GetAllStudentsSQL);
				if(students.size() > 0)
					lvStudentsList.setAdapter(new StudentListRowItemAdapter(this, students, onclick));
				break;
			case R.id.miStudentCall:
				Uri number = Uri.parse("tel:"+selectedStudent.phone);
				Intent dial = new Intent(Intent.ACTION_CALL, number);
				startActivity(dial);
				break;
			case R.id.miStudentEmail:
				String[] recipients = new String[]{selectedStudent.email, "",};
				Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
				emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, recipients);
				emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Test");
				emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "This is email's message");
				emailIntent.setType("text/plain");
				startActivity(Intent.createChooser(emailIntent, "Send mail..."));
				break;
			case R.id.miStudentSMS:
				Intent smsIntent= new Intent(Intent.ACTION_VIEW);
				smsIntent.putExtra("sms_body", "Hi,");
				smsIntent.putExtra("address",selectedStudent.phone );
				smsIntent.setType("vnd.android-dir/mms-sms");
				startActivity(smsIntent);
				break;
			}
		}
		return true;
	}
}
