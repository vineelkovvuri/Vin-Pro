package com.vineel;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class ListStudentGrades extends Activity {
	
	ListView lvGradesList = null;
	ArrayList<GradeDataObject> grades = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listgradeactivity);
		InitializeControls();
		
		//Fetch all students from students table and bind them to listview
		grades = DatabaseHelper.GetGradeRecords(this, DatabaseHelper.GetAllGradesSQL);
		if(grades.size() > 0)
			lvGradesList.setAdapter(new GradesListRowItemAdapter(this, grades));
		
	}

	private void InitializeControls() {
		lvGradesList = (ListView) findViewById(R.id.lvGradesList);
		lvGradesList.setClickable(true);
		
	}
}
