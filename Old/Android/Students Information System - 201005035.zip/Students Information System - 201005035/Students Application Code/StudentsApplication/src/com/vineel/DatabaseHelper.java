package com.vineel;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseHelper {

	static String DBNAME = "StudentsApplication.db";
	
	static String CreateStudentsTableSQL = "CREATE TABLE StudentDetails (" +
											"rollno TEXT PRIMARY KEY,name TEXT,"+
											"location TEXT, phone TEXT, email TEXT);";

	static String CreateCoursesTableSQL = "CREATE TABLE CourseDetails (" +
											"courseid TEXT PRIMARY KEY,name TEXT,"+
											"tutor TEXT, summary TEXT);";

	static String CreateGradesTableSQL = "CREATE TABLE GradeDetails (" +
											"rollno TEXT, courseid TEXT,"+
											"sem TEXT, grade TEXT, PRIMARY KEY (rollno, courseid));";
	
	static String GetAllStudentsSQL = "SELECT * FROM StudentDetails;";

	static String GetAllCoursesSQL = "SELECT * FROM CourseDetails;";
	
	static String GetAllGradesSQL = "SELECT * FROM GradeDetails ORDER BY rollno, sem, courseid, grade;";

	//static String 	"SELECT name FROM sqlite_master WHERE type='table' AND name='table_name';";


	public static void CreateTables(Context context){
		SQLiteDatabase dbCon;
		Cursor result ;
		dbCon = context.openOrCreateDatabase(DBNAME,SQLiteDatabase.CREATE_IF_NECESSARY,null);

		//Create Students Details if it doesnot exist
		result = dbCon.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='StudentDetails';", null);
		if(!result.moveToLast()) dbCon.execSQL(CreateStudentsTableSQL);

		//Create Course Details if it doesnot exist
		result = dbCon.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='CourseDetails';", null);
		if(!result.moveToLast()) dbCon.execSQL(CreateCoursesTableSQL);

		//Create Grades Details if it doesnot exist
		result = dbCon.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='GradeDetails';", null);
		if(!result.moveToLast()) dbCon.execSQL(CreateGradesTableSQL);
		
		dbCon.close();
		
	}
	public static long InsertRecord(Context context, String TableName, ContentValues values){
		SQLiteDatabase dbCon;
		//Cursor result ;
		dbCon = context.openOrCreateDatabase(DBNAME,SQLiteDatabase.CREATE_IF_NECESSARY,null);
		long result = dbCon.insert(TableName, null, values);
		dbCon.close();
		return result;
	}
	
	//this method fetches details of students
	public static ArrayList <StudentDataObject> GetStudentRecords(Context context, String SQL){
		
		ArrayList <StudentDataObject> results = new ArrayList<StudentDataObject>();
		SQLiteDatabase dbCon = context.openOrCreateDatabase(DBNAME,SQLiteDatabase.CREATE_IF_NECESSARY,null);
		Cursor result = dbCon.rawQuery(SQL, null);
		for(result.moveToFirst(); !result.isAfterLast();result.moveToNext())
			results.add(new StudentDataObject(result.getString(0),result.getString(1),result.getString(2),result.getString(3),result.getString(4)));
		
		dbCon.close();
		return results;
	}
	
	//this method fetches details of students
	public static ArrayList <CourseDataObject> GetCourseRecords(Context context, String SQL){
		
		ArrayList <CourseDataObject> results = new ArrayList<CourseDataObject>();
		SQLiteDatabase dbCon = context.openOrCreateDatabase(DBNAME,SQLiteDatabase.CREATE_IF_NECESSARY,null);
		Cursor result = dbCon.rawQuery(SQL, null);
		for(result.moveToFirst(); !result.isAfterLast();result.moveToNext())
			results.add(new CourseDataObject(result.getString(0),result.getString(1),result.getString(2),result.getString(3)));
		
		dbCon.close();
		return results;
	}
	//this method fetches details of students
	public static ArrayList <GradeDataObject> GetGradeRecords(Context context, String SQL){
		
		ArrayList <GradeDataObject> results = new ArrayList<GradeDataObject>();
		SQLiteDatabase dbCon = context.openOrCreateDatabase(DBNAME,SQLiteDatabase.CREATE_IF_NECESSARY,null);
		Cursor result = dbCon.rawQuery(SQL, null);
		for(result.moveToFirst(); !result.isAfterLast();result.moveToNext()){
			results.add(new GradeDataObject(result.getString(0),result.getString(1),result.getString(2),result.getString(3)));
			System.out.println(result.getString(0)+" "+result.getString(1)+" "+result.getString(2)+" "+result.getString(3));
		}
		
		dbCon.close();
		return results;
	}
	public static void DeleteRecord(Context context, String SQL){
		SQLiteDatabase dbCon = context.openOrCreateDatabase(DBNAME,SQLiteDatabase.CREATE_IF_NECESSARY,null);
		System.out.println(SQL);
		dbCon.execSQL(SQL);
		dbCon.close();
	}
	//SQlite dont support foreign key constraints. so we need to handle them.....
	public static boolean CheckRecordExists(Context context, String SQL){
		SQLiteDatabase dbCon = context.openOrCreateDatabase(DBNAME,SQLiteDatabase.CREATE_IF_NECESSARY,null);
		Cursor result = dbCon.rawQuery(SQL, null);
		boolean res = result.moveToLast();
		dbCon.close();
		return res;
	}
	
	
	
}
