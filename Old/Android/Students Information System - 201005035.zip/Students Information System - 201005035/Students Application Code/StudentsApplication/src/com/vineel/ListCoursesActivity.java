package com.vineel;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ListCoursesActivity extends Activity {
	ListView lvCoursesList = null;
	ArrayList<CourseDataObject> courses = null;	
	OnClickListener onclick = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listcoursesactivity);
		InitializeControls();

		//Fetch all courses from courses table and bind them to listview
		courses = DatabaseHelper.GetCourseRecords(this, DatabaseHelper.GetAllCoursesSQL);
		if(courses.size() > 0)
			lvCoursesList.setAdapter(new CoursesListRowItemAdapter(this, courses,onclick));
	}

	CourseDataObject selectedCourse;
	private void InitializeControls() {
		lvCoursesList = (ListView) findViewById(R.id.lvCoursesList);
		lvCoursesList.setTextFilterEnabled(true);
		onclick = new OnClickListener() {
			View previousSelectedView = null;
			@Override
			public void onClick(View v) {
				if(previousSelectedView != v){
					if(previousSelectedView != null){
						RadioGroup prevGP = (RadioGroup) previousSelectedView.findViewById(R.id.rbGroup);
						prevGP.clearCheck();
					}
					RadioButton rb = (RadioButton) v.findViewById(R.id.rbSelected);
					rb.setChecked(true);
					selectedCourse = (CourseDataObject) v.getTag();
					System.out.println(selectedCourse);
					previousSelectedView = v;
				}
			}
		};
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu); 
		getMenuInflater().inflate(R.menu.coursesreportmenu, menu); 
		return true;
	}
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		if(selectedCourse != null){
			String SQL;
			switch(item.getItemId()){
			case R.id.miCourseEdit:
				Intent intent = new Intent(this, CoursesActivity.class);
				intent.putExtra("StartedFromListCoursesActivity",true);
				intent.putExtra("courseID", selectedCourse.courseID);
				intent.putExtra("name", selectedCourse.name);
				intent.putExtra("tutor", selectedCourse.tutor);
				intent.putExtra("summary", selectedCourse.summary);
				startActivity(intent);
				break;
			case R.id.miCourseDelete:
				SQL = "DELETE FROM CourseDetails WHERE courseid='"+selectedCourse.courseID+"';";
				DatabaseHelper.DeleteRecord(this, SQL);
				Toast.makeText(this, "Selected Record Deleted....", Toast.LENGTH_LONG);
				//If record is deleted reload the data by
				//Fetching all courses from courses table and bind them to listview
				courses = DatabaseHelper.GetCourseRecords(this, DatabaseHelper.GetAllCoursesSQL);
				if(courses.size() > 0)
					lvCoursesList.setAdapter(new CoursesListRowItemAdapter(this, courses,onclick));
				
				break;
			}
		}
		return true;
	}
}
