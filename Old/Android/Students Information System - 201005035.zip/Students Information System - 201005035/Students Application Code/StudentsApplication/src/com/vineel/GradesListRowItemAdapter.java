package com.vineel;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class GradesListRowItemAdapter extends BaseAdapter {

	private Context context;
	private List<GradeDataObject> grades;
	android.view.View.OnClickListener onclick = null;
	public GradesListRowItemAdapter(Context context, List<GradeDataObject> grades) {
		super();
		this.context = context;
		this.grades = grades;
	}

	@Override
	public int getCount() {

		return grades.size();
	}

	@Override
	public Object getItem(int position) {

		return grades.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	//Gets called for each entry in the data list passed to the adapter
	public View getView(int position, View convertView, ViewGroup viewGroup) {
		GradeDataObject entry = grades.get(position);
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.gradeslistrowitem, null);
		}

		System.out.println(entry);
		TextView tvRollno = (TextView) convertView.findViewById(R.id.tvRollno);
		tvRollno.setText(entry.rollno);

		TextView tvCourseID = (TextView) convertView.findViewById(R.id.tvCourseID);
		tvCourseID.setText(entry.courseID);

		TextView tvSemister = (TextView) convertView.findViewById(R.id.tvSemister);
		tvSemister.setText(entry.semister);

		TextView tvGrade = (TextView) convertView.findViewById(R.id.tvGrade);
		tvGrade.setText(entry.grade);

		return convertView;
	}


}
