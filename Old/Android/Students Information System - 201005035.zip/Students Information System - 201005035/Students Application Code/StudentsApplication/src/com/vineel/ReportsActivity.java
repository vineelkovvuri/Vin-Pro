package com.vineel;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ReportsActivity extends Activity {
	
	
	Button bListStudents,
	bListCourses,
	bStudentGrades;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reportsactivity);
		InitializeControls();

		OnClickListener onclick = new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = null;
				switch(v.getId()){
				case R.id.bListStudents:
					intent = new Intent(ReportsActivity.this, ListStudentActivity.class);
					break;
				case R.id.bListCourses:
					intent = new Intent(ReportsActivity.this, ListCoursesActivity.class);
					break;
				case R.id.bStudentGrades:
					intent = new Intent(ReportsActivity.this, ListStudentGrades.class);
					break;
				}
				startActivity(intent);
			}
		};

		bListStudents.setOnClickListener(onclick);
		bListCourses.setOnClickListener(onclick);
		bStudentGrades.setOnClickListener(onclick);
	}

	private void InitializeControls() {

		bListStudents = (Button) findViewById(R.id.bListStudents);
		bListCourses = (Button) findViewById(R.id.bListCourses);
		bStudentGrades = (Button) findViewById(R.id.bStudentGrades);
		
		//setTitle(getTitle()+" - Reports");
	}
}
