package com.vineel;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class StudentsApplicationMainActivity extends Activity {

	Button bCoursesDetails,
	bStudentsDetails,
	bGradesDetails,
	bReports;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		InitializeControls();

		OnClickListener onclick = new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = null;
				switch(v.getId()){
				case R.id.bCoursesDetails:
					intent = new Intent(StudentsApplicationMainActivity.this, CoursesActivity.class);
					break;
				case R.id.bStudentsDetails:
					intent = new Intent(StudentsApplicationMainActivity.this, StudentsActivity.class);
					break;
				case R.id.bGradesDetails:
					intent = new Intent(StudentsApplicationMainActivity.this, GradesActivity.class);
					break;
				case R.id.bReports:
					intent = new Intent(StudentsApplicationMainActivity.this, ReportsActivity.class);
					break;
				}
				startActivity(intent);
			}
		};


		bCoursesDetails.setOnClickListener(onclick);
		bStudentsDetails.setOnClickListener(onclick);
		bGradesDetails.setOnClickListener(onclick);
		bReports.setOnClickListener(onclick);

		//Initiate Database 
		DatabaseHelper.CreateTables(this);
		
	}

	private void InitializeControls() {
		bCoursesDetails = (Button) findViewById(R.id.bCoursesDetails);
		bStudentsDetails = (Button) findViewById(R.id.bStudentsDetails);
		bGradesDetails = (Button) findViewById(R.id.bGradesDetails);
		bReports = (Button) findViewById(R.id.bReports);
	}

}