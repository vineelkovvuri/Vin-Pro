package com.vineel;

public class StudentDataObject {
	
	String rollno;
	String name;
	String location;
	String phone;
	String email;
	public StudentDataObject(String rollno, String name, String location,
			String phone, String email) {
		super();
		this.rollno = rollno;
		this.name = name;
		this.location = location;
		this.phone = phone;
		this.email = email;
	}
	@Override
	public String toString() {
		return "StudentDataObject [rollno=" + rollno + ", name=" + name
				+ ", location=" + location + ", phone=" + phone + ", email="
				+ email + "]";
	}
	
	
	
}
