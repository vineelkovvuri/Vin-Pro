package com.vineel;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class StudentsActivity extends Activity {

	EditText etName,
	etRollNo,
	etEmail,
	etPhone,
	etLocation;

	Button bAddStudent;	
	
	boolean StartedFromListStudentActivity = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.studentsactivity);
		InitializeControls();
		
		//If this activity is invoked from ListStudentActivity the prepopulate the data from intent
		Intent caller = getIntent();
		if(caller != null && caller.getExtras() != null && caller.getExtras().getBoolean("StartedFromListStudentActivity")){
			StartedFromListStudentActivity = true;
			etRollNo.setText(caller.getExtras().getString("rollno"));
			etName.setText(caller.getExtras().getString("name"));
			etEmail.setText(caller.getExtras().getString("email"));
			etPhone.setText(caller.getExtras().getString("phone"));
			etLocation.setText(caller.getExtras().getString("location"));
		}
		
		bAddStudent.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String rollno = etRollNo.getText().toString();
				String name = etName.getText().toString();
				String email = etEmail.getText().toString();
				String phone = etPhone.getText().toString();
				String location = etLocation.getText().toString();
				Log.i("APP:",rollno+" "+name+" "+email+" "+phone+" "+location);
				if("".equals(rollno)||"".equals(name)||"".equals(email)||"".equals(phone)||"".equals(location)){
					Toast.makeText(StudentsActivity.this, "Please enter valid data", Toast.LENGTH_LONG).show(); 
				}
				else if(rollno.length() != 9){
					Toast.makeText(StudentsActivity.this, "Entered Rollno should be exactly 9 digts(ex: 201005035)..", Toast.LENGTH_LONG).show();
				}
				else{
					if(StartedFromListStudentActivity){
						//if started from List student activity we need to delete the existing row and insert a new row
						String SQL = "DELETE FROM StudentDetails WHERE rollno='"+rollno+"'";
						DatabaseHelper.DeleteRecord(StudentsActivity.this, SQL);
					}
					ContentValues values = new ContentValues();
					values.put("rollno", rollno);
					values.put("name", name);
					values.put("location", location);
					values.put("phone", phone);
					values.put("email", email);
					long result = DatabaseHelper.InsertRecord(StudentsActivity.this, "StudentDetails", values);
					if(result != -1){
						Toast.makeText(StudentsActivity.this, "Record Inserted...", Toast.LENGTH_LONG).show();
						 startActivity(new Intent(StudentsActivity.this,StudentsApplicationMainActivity.class));
						 StartedFromListStudentActivity = false;
					}
					else{
						Toast.makeText(StudentsActivity.this, "Record Insertion Failed...", Toast.LENGTH_LONG).show();
					}
				}
				
			}
		});

	}

	private void InitializeControls() {
		etName = (EditText) findViewById(R.id.etName);
		etRollNo = (EditText) findViewById(R.id.etRollNo);
		etEmail = (EditText) findViewById(R.id.etEmail);
		etPhone = (EditText) findViewById(R.id.etPhone);
		etLocation = (EditText) findViewById(R.id.etLocation);
		bAddStudent = (Button) findViewById(R.id.bAddStudent);

	}
}
