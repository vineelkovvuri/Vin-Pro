package com.vineel;

import java.util.Random;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CoursesActivity extends Activity {

	EditText etCourseName,
	etTutor,
	etTopics;
	TextView tvCourseId;
	Button bAddCourse;
	boolean StartedFromListCoursesActivity = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.coursesactivity);
		InitializeControls();
		//If this activity is invoked from ListCoursesActivity the prepopulate the data from intent
		Intent caller = getIntent();
		if(caller != null && caller.getExtras() != null && caller.getExtras().getBoolean("StartedFromListCoursesActivity")){
			StartedFromListCoursesActivity = true;
			tvCourseId.setText(caller.getExtras().getString("courseID"));
			etCourseName.setText(caller.getExtras().getString("name"));
			etTutor.setText(caller.getExtras().getString("tutor"));
			etTopics.setText(caller.getExtras().getString("summary"));
		}
		
		
		bAddCourse.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String courseid = tvCourseId.getText().toString();
				String name = etCourseName.getText().toString();
				String tutor = etTutor.getText().toString();
				String summary = etTopics.getText().toString();
				Log.i("APP:",courseid+" "+name+" "+tutor+" "+summary);
				if("".equals(courseid)||"".equals(name)||"".equals(tutor)||"".equals(summary)){
					Toast.makeText(CoursesActivity.this, "Please enter valid data", Toast.LENGTH_LONG).show(); 
				}
				else{
					if(StartedFromListCoursesActivity){
						//if started from List student activity we need to delete the existing row and insert a new row
						String SQL = "DELETE FROM CourseDetails WHERE courseid='"+courseid+"'";
						DatabaseHelper.DeleteRecord(CoursesActivity.this, SQL);
					}
					ContentValues values = new ContentValues();
					values.put("courseid", courseid);
					values.put("name", name);
					values.put("tutor", tutor);
					values.put("summary", summary);
					long result = DatabaseHelper.InsertRecord(CoursesActivity.this, "CourseDetails", values);
					if(result != -1){
						Toast.makeText(CoursesActivity.this, "Record Inserted...", Toast.LENGTH_LONG).show();
						 startActivity(new Intent(CoursesActivity.this,StudentsApplicationMainActivity.class));
						 StartedFromListCoursesActivity = false;
					}
					else{
						Toast.makeText(CoursesActivity.this, "Record Insertion Failed...", Toast.LENGTH_LONG).show();
					}
				}
			}
		});

		//Generate new Courseid only if a new course is entered from the application main screen
		//else resue the previously assigned courseid
		if(!StartedFromListCoursesActivity){
			String rndCourseID = GeneratedCourseID();
			tvCourseId.setText(rndCourseID);
		}
	}

	private static String GeneratedCourseID() {
		String courseID = "CS";
		Random rnd = new Random(System.nanoTime());
		courseID += Math.abs(rnd.nextInt())%10+""+Math.abs(rnd.nextInt())%10+""+Math.abs(rnd.nextInt())%10+""+Math.abs(rnd.nextInt())%10;
		return courseID; 
	}

	private void InitializeControls() {
		etCourseName = (EditText) findViewById(R.id.etCourseName);
		etTutor = (EditText) findViewById(R.id.etTutor);
		etTopics = (EditText) findViewById(R.id.etTopics);
		tvCourseId = (TextView) findViewById(R.id.tvCourseId);
		bAddCourse = (Button) findViewById(R.id.bAddCourse);
	}
}
