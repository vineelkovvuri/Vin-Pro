package com.vineel;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RadioButton;
import android.widget.TextView;

public class CoursesListRowItemAdapter extends BaseAdapter {

	private Context context;
	private List<CourseDataObject> courses;
	android.view.View.OnClickListener onclick = null;
	public CoursesListRowItemAdapter(Context context, List<CourseDataObject> courses,android.view.View.OnClickListener onclick) {
		super();
		this.context = context;
		this.courses = courses;
		this.onclick = onclick;
	}

	@Override
	public int getCount() {

		return courses.size();
	}

	@Override
	public Object getItem(int position) {

		return courses.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
	//Gets called for each entry in the data list passed to the adapter
	public View getView(int position, View convertView, ViewGroup viewGroup) {
		CourseDataObject entry = courses.get(position);
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.courseslistrowitem, null);
		}

		System.out.println(entry);
		TextView tvName = (TextView) convertView.findViewById(R.id.tvName);
		tvName.setText(entry.name);

		TextView tvTutor = (TextView) convertView.findViewById(R.id.tvTutor);
		tvTutor.setText(entry.tutor);

		TextView tvSummary = (TextView) convertView.findViewById(R.id.tvSummary);
		tvSummary.setText(entry.summary);

		TextView tvCourseID = (TextView) convertView.findViewById(R.id.tvCourseID);
		tvCourseID.setText(entry.courseID);


		RadioButton rbSelected = (RadioButton) convertView.findViewById(R.id.rbSelected);
		rbSelected.setFocusable(false);
		rbSelected.setClickable(false);
		rbSelected.setOnClickListener(onclick);
		
		convertView.setTag(entry);

		convertView.setOnClickListener(onclick);

		return convertView;
	}
}
