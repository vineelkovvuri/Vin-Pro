package com.vineel;

public class GradeDataObject {
	String rollno;
	String courseID;
	String semister;
	String grade;
	
	public GradeDataObject(String rollno, String courseID, String semister,
			String grade) {
		super();
		this.rollno = rollno;
		this.courseID = courseID;
		this.semister = semister;
		this.grade = grade;
	}



	@Override
	public String toString() {
		return "GradeDateObject ["
				+ (rollno != null ? "rollno=" + rollno + ", " : "")
				+ (courseID != null ? "courseID=" + courseID + ", " : "")
				+ (semister != null ? "semister=" + semister + ", " : "")
				+ (grade != null ? "grade=" + grade : "") + "]";
	}
	
}
