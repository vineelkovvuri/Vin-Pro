package com.vineel;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GradesActivity extends Activity {

	EditText etRollNo,
	etCourseId,
	etSemister,
	etGrade;
	Button bUpdateGrade;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gradesactivity);
		InitializeControls();
		bUpdateGrade.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String rollno = etRollNo.getText().toString();
				String courseid = etCourseId.getText().toString().toUpperCase();
				String sem = etSemister.getText().toString();
				String grade = etGrade.getText().toString();
				if("".equals(rollno)||"".equals(courseid)||"".equals(sem)||"".equals(grade)){
					Toast.makeText(GradesActivity.this, "Please enter valid data", Toast.LENGTH_LONG).show(); 
				}
				else{
					//SQlite did not support foreign key constraints before version 3.6.19
					//So we need to handle them
					String SQLCourseIDCheck = "SELECT * FROM CourseDetails  WHERE courseid='"+courseid+"';";
					String SQLRollnoCheck   = "SELECT * FROM StudentDetails WHERE rollno='"+rollno+"';";
					if(DatabaseHelper.CheckRecordExists(GradesActivity.this, SQLRollnoCheck) && DatabaseHelper.CheckRecordExists(GradesActivity.this, SQLCourseIDCheck) ){
						ContentValues values = new ContentValues();
						values.put("rollno", rollno);
						values.put("courseid", courseid);
						values.put("sem", sem);
						values.put("grade", grade);
						long result = DatabaseHelper.InsertRecord(GradesActivity.this, "GradeDetails", values);
						if(result != -1){
							Toast.makeText(GradesActivity.this, "Record Inserted...", Toast.LENGTH_LONG).show();
							 startActivity(new Intent(GradesActivity.this,StudentsApplicationMainActivity.class));
						}
						else{
							Toast.makeText(GradesActivity.this, "Record Insertion Failed...", Toast.LENGTH_LONG).show();
						}
					}
					else{
						Toast.makeText(GradesActivity.this, "Course ID or Student roll number do not exist.....", Toast.LENGTH_LONG).show(); 
					}
				}
			}
		});

	}

	private void InitializeControls() {

		etRollNo = (EditText) findViewById(R.id.etRollNo);
		etCourseId = (EditText) findViewById(R.id.etCourseId);
		etSemister = (EditText) findViewById(R.id.etSemister);
		etGrade = (EditText) findViewById(R.id.etGrade);
		bUpdateGrade = (Button) findViewById(R.id.bUpdateGrade);

	}
}
