package com.vineel;

public class CourseDataObject {
	String courseID;
	String name;
	String tutor;
	String summary;
	public CourseDataObject(String courseID, String name, String tutor,
			String summary) {
		super();
		this.courseID = courseID;
		this.name = name;
		this.tutor = tutor;
		this.summary = summary;
	}
	@Override
	public String toString() {
		return "CourseDataObject ["
				+ (courseID != null ? "courseID=" + courseID + ", " : "")
				+ (name != null ? "name=" + name + ", " : "")
				+ (tutor != null ? "tutor=" + tutor + ", " : "")
				+ (summary != null ? "summary=" + summary : "") + "]";
	}
	
	
}
