package com.vineel;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

public class RestaurantResultsActivity extends Activity {
	
	ListView lvResults = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.results);
		
		InitiateControls();
		String Location = (String) getIntent().getExtras().get("location");
		String Cuisine = (String) getIntent().getExtras().get("cuisine");
		
		//pass this context, listview reference and invoke fetch on async task
		new RestaurantReviews(this,lvResults,this).execute(Location,Cuisine);
		
	}
	
	private void InitiateControls() {
		lvResults = (ListView) findViewById(R.id.lvResults);
		lvResults.setTextFilterEnabled(true);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu); 
		getMenuInflater().inflate(R.menu.resultsmenu, menu); 
		return true;
	}
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item); 
		if(item.getItemId() == R.id.migoback){
			startActivity(new Intent(RestaurantResultsActivity.this, RestaurantsActivity.class));
		}
		return true;
	}
}
