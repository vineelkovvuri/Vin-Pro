package com.vineel;


//Final restaurant object which encapsulate complete details of a restaurant

public class Restaurant {
	String lat;
	String lng;
	String name;
	String vicinity;
	String phoneno;
	String formatedAddress;
	String rating;
	String mapurl;
	String reference;
	public Restaurant(String lat, String lng, String name, String vicinity,
			String phoneno, String formatedAddress, String rating,
			String mapurl, String reference) {
		super();
		this.lat = lat;
		this.lng = lng;
		this.name = name;
		this.vicinity = vicinity;
		this.phoneno = phoneno;
		this.formatedAddress = formatedAddress;
		this.rating = rating;
		this.mapurl = mapurl;
		this.reference = reference;
	}
	@Override
	public String toString() {
		return "Restaurant [lat=" + lat + ", lng=" + lng + ", name=" + name
				+ ", vicinity=" + vicinity + ", phoneno=" + phoneno
				+ ", formatedAddress=" + formatedAddress + ", rating=" + rating
				+ ", mapurl=" + mapurl + ", reference=" + reference + "]";
	}	
	
	
}




