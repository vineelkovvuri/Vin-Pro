package com.vineel;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;
//                                               param , progess, result
public class RestaurantReviews extends AsyncTask<String, Double, ArrayList<Restaurant>>{

	ListView lvResults = null;
	Context context = null;
	Activity activity = null;
	public RestaurantReviews(Context context, ListView lvResults, Activity activity) {
		super();
		this.context = context;
		this.lvResults = lvResults;
		this.activity = activity;
	}
	//This method takes location(user typed)and cuisine and returns the restaurants present at that location
	//It gets invoke from bottom doInBackground Async method 
	public ArrayList<Restaurant> GetReviews(String location,String cuisine) {

		Double progress;	
		//make sure location dont have spaces
		location = location.replace(' ', '+');
		
		//Get approximate lat lng for given location(given by user) 
		//for one given location say redmond we may have more than one result "Redmond, WA, USA" , "Redmond, OR, USA" , "Redmond, UT, USA"
		//with their respective latitudes and longitudes
		//So places array list will hold all the returned places for the given location
		ArrayList<RestaurantPlace> places = new ArrayList<RestaurantPlace>();
		StringBuffer sb = RestaurantHelper.GetSource("http://maps.googleapis.com/maps/api/geocode/json?address="+location+"&sensor=false",false);
		progress = 0.0;
		try{
			String line = sb.toString();
			JSONObject jo = new JSONObject(line);
			JSONArray res  = (JSONArray) jo.get("results");
			for (int j = 0; j < res.length(); j++) {
				JSONObject result = (JSONObject) res.get(j);
				String formatedAddress = result.optString("formatted_address");
				JSONObject lnglat = (JSONObject)((JSONObject)((JSONObject)result.get("geometry")).get("bounds")).get("northeast");
				String lat = lnglat.optString("lat");
				String lng = lnglat.optString("lng");
				//push each place in to places arraylist
				places.add(new RestaurantPlace(formatedAddress, lng, lat));
				publishProgress((++progress)*100/res.length());
				//Log.i("info:",formatedAddress+"  "+lat+"  "+lng);
			}                
		}catch(Exception e){
			Log.i("Places info:",e.getMessage());
		}

		//Get the restaurants around each place obtained above
		//This arraylist hold the results obtained for each restaurant
		ArrayList<Restaurant> restaurants = new ArrayList<Restaurant>();
		progress = 0.0;
		for(RestaurantPlace place : places){
			//types parameter in url retrieves desired places about the lat and lng
			sb = RestaurantHelper.GetSource("https://maps.googleapis.com/maps/api/place/search/json?location="+place.lat+","+place.lng+
					"&radius=500&types=restaurant|food|cafe|bakery&name="+cuisine+"&sensor=false&key=AIzaSyAcOyBCfhgNCkOR2W_sFA6gCX5xQdifqIc",true);
			try{
				String line = sb.toString();
				JSONObject jo = new JSONObject(line);
				JSONArray resultsArray  = (JSONArray) jo.get("results");
				for (int j = 0; j < resultsArray.length(); j++) {
					JSONObject result = (JSONObject) resultsArray.get(j);
					String name = result.optString("name");
					String vicinity = result.optString("vicinity");
					String reference = result.optString("reference");
					JSONObject lnglat = (JSONObject)((JSONObject)result.get("geometry")).get("location");
					String lat = lnglat.optString("lat");
					String lng = lnglat.optString("lng");
					//push each restaurant in to restaurants arraylist
					restaurants.add(new Restaurant(lat, lng, name, vicinity, null, null, null, null, reference));
					//	Log.i("info:","lat=" + lat + ", lng=" + lng + ", name="+ name + ", vicinity=" + vicinity + ", reference=" + reference);
				}   
				publishProgress((++progress)*100/places.size());
			}catch(Exception e){
				Log.i("Restaurant info:",e.getMessage());
			}

		}

		//Ratings for each restaurant should be obtained separately by passing reference associated with each restaurant
		progress = 0.0;
		for(Restaurant restaurant:restaurants){
			sb = RestaurantHelper.GetSource("https://maps.googleapis.com/maps/api/place/details/json?reference="+restaurant.reference+
					"&sensor=false&key=AIzaSyAcOyBCfhgNCkOR2W_sFA6gCX5xQdifqIc",true);
			try{
				String line = sb.toString();
				JSONObject jo = new JSONObject(line);
				JSONObject restaurantDetails  = (JSONObject) jo.get("result");
				restaurant.formatedAddress = restaurantDetails.optString("formatted_address");
				restaurant.phoneno = restaurantDetails.optString("formatted_phone_number");
				restaurant.rating  = restaurantDetails.optString("rating");
				restaurant.mapurl = restaurantDetails.optString("url");
				publishProgress((++progress)*100/restaurants.size());
				//	Log.i("info:",restaurant.toString());
			}catch(Exception e){
				Log.i("Rating info:",e.getMessage());
			}
		}

		//its good we sort the restaurants by rating
		Collections.sort(restaurants, new RestaurantSorter());

		return restaurants;
	}
	//Custom Compare function to sort restaurant object by rating......
	static class RestaurantSorter implements Comparator<Restaurant>{
		@Override
		public int compare(Restaurant restaurant1, Restaurant restaurant2) {
			double rating1,rating2;
			rating1 = "".equals(restaurant1.rating)? 0: Double.parseDouble(restaurant1.rating);
			rating2 = "".equals(restaurant2.rating)? 0: Double.parseDouble(restaurant2.rating);

			if(rating1 < rating2)return 1;
			else if(rating1 > rating2)return -1;
			return 0;
		}
	}

	//----------------------------------------------------------------------------------------------------------------------
	/**
	 * 				This Async Task is useful to fetch Restaurant results in the background
	 * 				This keep the UI thread responsive...... 
	 */

	@Override
	//This is invoked on the UI Thread so np.....we can manipulate UI controls of Activity
	protected void onPreExecute() {
		Toast.makeText(context, "Please wait while the results are being fetched.....", Toast.LENGTH_LONG).show();
		super.onPreExecute();
	}
	@Override
	protected ArrayList<Restaurant> doInBackground(String... params) {
		return GetReviews(params[0], params[1]);	// location, cuisine
	}
	DecimalFormat decimalFormater = new DecimalFormat("##.00");
	@Override
	protected void onProgressUpdate(Double... values) {
		
		activity.setTitle("Restaurants Results..."+decimalFormater.format(values[0])+"% Done");
		super.onProgressUpdate(values);
	}
	
	@Override
	//This is invoked on the UI Thread so np.....
	protected void onPostExecute(ArrayList<Restaurant> result) {

		activity.setTitle("Restaurants Results");
		
		if(result.size() == 0)
			Toast.makeText(context, "Zero results fetched. Try with other location.....", Toast.LENGTH_LONG).show();
		else{
			ResultRowAdapter adapter = new ResultRowAdapter(context, result);
			lvResults.setAdapter(adapter);
		}
		super.onPostExecute(result);
	}
}
