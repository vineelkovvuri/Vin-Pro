package com.vineel;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class RestaurantsActivity extends Activity {

	EditText etLocation = null;
	Button btGetReviews = null;
	Spinner spCuisine = null;
	String spCuisineList[] = null;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);


		InitiateControls();

		btGetReviews = (Button) findViewById(R.id.btReviews);
		btGetReviews.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String Location = etLocation.getText().toString(); 
				String Cuisine = (String) spCuisine.getSelectedItem();

				if(Location.isEmpty()){
					Toast.makeText(RestaurantsActivity.this, "Please enter a location", Toast.LENGTH_LONG).show(); 
				}
				else{
					 Intent intent = new Intent(RestaurantsActivity.this, RestaurantResultsActivity.class);
					 intent.putExtra("location", Location);
					 intent.putExtra("cuisine", Cuisine);
					 startActivity(intent);
				}
			}
		});
	}


	private void InitiateControls() {
		ArrayAdapter<CharSequence> adapter = null;
		Resources res = getResources();

		etLocation = (EditText)findViewById(R.id.etLocation);
		spCuisine = (Spinner)findViewById(R.id.spCuisine);
		spCuisineList = res.getStringArray(R.array.Cuisines);

		adapter = ArrayAdapter.createFromResource(this, R.array.Cuisines, android.R.layout.simple_spinner_item );
		adapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
		spCuisine.setAdapter(adapter);
		//		spCuisine.setSelection(3);

	}


}


