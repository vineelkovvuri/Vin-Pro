package com.vineel;

//this class is helpfull for the first time in converting 
//user entered location to their approximate lat, lng locations
//once lat,lng are obtained we make use of Restaurant class
// ITS JUST A PLACE HOLDER......
public class RestaurantPlace {
	String formatedAddress;
	String lng;
	String lat;
	public RestaurantPlace(String formatedAddress, String lng, String lat) {
		super();
		this.formatedAddress = formatedAddress;
		this.lng = lng;
		this.lat = lat;
	}
	@Override
	public String toString() {
		return "RestaurantPlace [formatedAddress=" + formatedAddress + ", lng="
				+ lng + ", lat=" + lat + "]";
	}
	
}
