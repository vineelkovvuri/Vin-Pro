package com.vineel;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ResultRowAdapter extends BaseAdapter implements OnClickListener {

	private Context context;
    private List<Restaurant> restaurants;
    
	public ResultRowAdapter(Context context, List<Restaurant> restaurants) {
		super();
		this.context = context;
		this.restaurants = restaurants;
	}

	@Override
	public int getCount() {

		return restaurants.size();
	}

	@Override
	public Object getItem(int position) {

		return restaurants.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	//Gets called for each entry in the data list passed to the adapter
	public View getView(int position, View convertView, ViewGroup viewGroup) {
        Restaurant entry = restaurants.get(position);
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.result_row, null);
        }
        TextView tvRestaurantName = (TextView) convertView.findViewById(R.id.tvRestaurantName);
        tvRestaurantName.setText(entry.name);

        TextView tvRating = (TextView) convertView.findViewById(R.id.tvRating);
        tvRating.setText(entry.rating);

        TextView tvPhone = (TextView) convertView.findViewById(R.id.tvPhone);
        tvPhone.setText(entry.phoneno);

        TextView tvAddress = (TextView) convertView.findViewById(R.id.tvAddress);
        tvAddress.setText(entry.formatedAddress);

        return convertView;
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}

}
